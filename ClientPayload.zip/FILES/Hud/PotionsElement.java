package org.eloria.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import org.eloria.utils.ColorUtil;
import org.eloria.utils.render.Theme;
import org.eloria.utils.render.gui.MsdfFont;
import org.eloria.utils.render.gui.Render2DUtil;
import org.eloria.utils.render.gui.TextAlign;
import org.eloria.utils.render.gui.UiFontStyle;
import org.eloria.utils.render.gui.UiFonts;
import org.eloria.utils.render.Textures;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PotionsElement extends HudElement {
    private static final int CHIP_BG = ColorUtil.rgba(9, 9, 12, 205);
    private static final int TEXT_SUBTITLE = ColorUtil.rgba(255, 255, 255, 150);
    private static final String[] ROMAN = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private static final float TITLE_SIZE = 11.0F;
    private static final float NAME_SIZE = 10.0F;
    private static final float TIME_SIZE = 10.0F;

    private static final float HEADER_HEIGHT = 24.0F;
    private static final float HEADER_ICON_SIZE = 12.0F;
    private static final float ROW_HEIGHT = 21.0F;
    private static final float EFFECT_ICON_SIZE = 11.0F;
    private static final float CHIP_GAP = 4.0F;
    private static final float ROW_GAP = 5.0F;
    private static final float HEADER_GAP = 8.0F;
    private static final float CHIP_PADDING_X = 8.0F;
    private static final float HEADER_PAD_EXTRA = 4.0F;
    private static final float CHIP_RADIUS = 7.0F;
    private static final float INNER_GAP = 5.0F;
    private static final int MAX_NAME_CHARS = 18;

    private record Card(Identifier icon, String name, String time, boolean harmful) {
    }

    private final List<Card> cards = new ArrayList<>();

    public PotionsElement() {
        super("potions", "Potions");
    }

    @Override
    protected float defaultY(float unit) {
        return 260.0F * unit;
    }

    @Override
    protected void layout(Minecraft mc, float unit) {
        collectCards(mc);
        if (this.cards.isEmpty()) {
            this.width = 0.0F;
            this.height = 0.0F;
            return;
        }

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = NAME_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();

        float timeWidth = 0.0F;
        float[] nameWidths = new float[this.cards.size()];
        for (int i = 0; i < this.cards.size(); i++) {
            Card card = this.cards.get(i);
            nameWidths[i] = font.measureWidth(truncate(card.name()), textSize, letterSpacing);
            timeWidth = Math.max(timeWidth,
                    font.measureWidth(card.time(), TIME_SIZE * unit, TIME_SIZE * unit * UiFontStyle.MEDIUM.letterSpacingEm()));
        }

        float leftChip = CHIP_PADDING_X * unit + EFFECT_ICON_SIZE * unit + INNER_GAP * unit
                + timeWidth + CHIP_PADDING_X * unit;

        float listWidth = 0.0F;
        for (float nameWidth : nameWidths) {
            float rightChip = CHIP_PADDING_X * unit + nameWidth + CHIP_PADDING_X * unit;
            listWidth = Math.max(listWidth, leftChip + CHIP_GAP * unit + rightChip);
        }

        float headerWidth = CHIP_PADDING_X * unit + HEADER_ICON_SIZE * unit + INNER_GAP * unit
                + font.measureWidth("Potions", TITLE_SIZE * unit, TITLE_SIZE * unit * UiFontStyle.SEMIBOLD.letterSpacingEm())
                + (CHIP_PADDING_X + HEADER_PAD_EXTRA) * unit;

        this.width = Math.max(listWidth, headerWidth);
        this.height = (HEADER_HEIGHT + HEADER_GAP + this.cards.size() * ROW_HEIGHT
                + (this.cards.size() - 1) * ROW_GAP) * unit;
    }

    @Override
    protected void draw(Minecraft mc, float unit) {
        if (this.cards.isEmpty()) {
            return;
        }

        float alpha = appearAlpha();
        MsdfFont font = UiFonts.sfProDisplay();

        // ===== ЗАГОЛОВОК: плашка с иконкой колбы и "Potions", ширина только по содержимому =====
        int accent = Theme.getAccent();
        float headerWidth = CHIP_PADDING_X * unit + HEADER_ICON_SIZE * unit + INNER_GAP * unit
                + font.measureWidth("Potions", TITLE_SIZE * unit, TITLE_SIZE * unit * UiFontStyle.SEMIBOLD.letterSpacingEm())
                + (CHIP_PADDING_X + HEADER_PAD_EXTRA) * unit;
        Render2DUtil.rect(this.x, this.y, headerWidth, HEADER_HEIGHT * unit)
                .color(ColorUtil.multiplyAlpha(tintWithAccent(CHIP_BG, accent), alpha))
                .radius(CHIP_RADIUS * unit)
                .shadow(ColorUtil.rgba(0, 0, 0, 110), 9.0F * unit)
                .blur(8.0F * unit, alpha)
                .draw();
        float headerIconSize = HEADER_ICON_SIZE * unit;
        Render2DUtil.texture(this.x + CHIP_PADDING_X * unit,
                        this.y + (HEADER_HEIGHT * unit - headerIconSize) / 2.0F,
                        headerIconSize, headerIconSize, Textures.Icons.FLASK)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .draw();
        float titleSize = TITLE_SIZE * unit;
        Render2DUtil.text(this.x + CHIP_PADDING_X * unit + headerIconSize + INNER_GAP * unit,
                        font.centeredTextY(this.y + HEADER_HEIGHT * unit / 2.0F, titleSize),
                        titleSize, "Potions")
                .style(UiFontStyle.SEMIBOLD)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                .align(TextAlign.LEFT)
                .draw();

        // ===== СТРОКИ: чип [иконка + время] + чип [название] =====
        float textSize = NAME_SIZE * unit;
        float timeSize = TIME_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();

        float timeWidth = 0.0F;
        float[] nameWidths = new float[this.cards.size()];
        for (int i = 0; i < this.cards.size(); i++) {
            Card card = this.cards.get(i);
            nameWidths[i] = font.measureWidth(truncate(card.name()), textSize, letterSpacing);
            timeWidth = Math.max(timeWidth,
                    font.measureWidth(card.time(), timeSize, timeSize * UiFontStyle.MEDIUM.letterSpacingEm()));
        }
        float leftChipWidth = CHIP_PADDING_X * unit + EFFECT_ICON_SIZE * unit + INNER_GAP * unit
                + timeWidth + CHIP_PADDING_X * unit;

        float rowY = this.y + (HEADER_HEIGHT + HEADER_GAP) * unit;
        for (int i = 0; i < this.cards.size(); i++) {
            Card card = this.cards.get(i);
            float rowHeight = ROW_HEIGHT * unit;

            // Левый чип: иконка эффекта + таймер
            Render2DUtil.rect(this.x, rowY, leftChipWidth, rowHeight)
                    .glass(alpha, 0.5F * unit, 8.0F * unit)
                    .radius(CHIP_RADIUS * unit)
                    .draw();
            float iconSize = EFFECT_ICON_SIZE * unit;
            float chipCenterY = rowY + rowHeight / 2.0F;
            Render2DUtil.texture(this.x + CHIP_PADDING_X * unit, chipCenterY - iconSize / 2.0F,
                            iconSize, iconSize, card.icon())
                    .color(ColorUtil.multiplyAlpha(ColorUtil.WHITE, alpha))
                    .draw();
            float timeTextY = font.centeredTextY(chipCenterY, timeSize);
            Render2DUtil.text(this.x + CHIP_PADDING_X * unit + iconSize + INNER_GAP * unit, timeTextY,
                            timeSize, card.time())
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(card.harmful() ? Theme.Colors.SYSTEM_RED : TEXT_SUBTITLE, alpha))
                    .align(TextAlign.LEFT)
                    .draw();

            // Правый чип: название эффекта, ширина ровно по тексту
            float rightChipWidth = CHIP_PADDING_X * unit + nameWidths[i] + CHIP_PADDING_X * unit;
            float rightChipX = this.x + leftChipWidth + CHIP_GAP * unit;
            Render2DUtil.rect(rightChipX, rowY, rightChipWidth, rowHeight)
                    .glass(alpha, 0.5F * unit, 8.0F * unit)
                    .radius(CHIP_RADIUS * unit)
                    .draw();
            Render2DUtil.text(rightChipX + CHIP_PADDING_X * unit,
                            font.centeredTextY(chipCenterY, textSize),
                            textSize, truncate(card.name()))
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                    .align(TextAlign.LEFT)
                    .draw();

            rowY += (ROW_HEIGHT + ROW_GAP) * unit;
        }
    }

    private static String truncate(String name) {
        if (name.length() > MAX_NAME_CHARS) {
            return name.substring(0, MAX_NAME_CHARS - 1) + "\u2026";
        }
        return name;
    }

    // Лёгкий подкрашивающий микс: ~18% акцента поверх базового цвета
    private static int tintWithAccent(int base, int accent) {
        float mix = 0.18F;
        int r = (int) ((base >> 16 & 0xFF) + ((accent >> 16 & 0xFF) - (base >> 16 & 0xFF)) * mix);
        int g = (int) ((base >> 8 & 0xFF) + ((accent >> 8 & 0xFF) - (base >> 8 & 0xFF)) * mix);
        int b = (int) ((base & 0xFF) + ((accent & 0xFF) - (base & 0xFF)) * mix);
        return ColorUtil.rgba(r, g, b, base >>> 24);
    }

    private void collectCards(Minecraft mc) {
        this.cards.clear();
        Map<Identifier, MobEffectInstance> unique = new LinkedHashMap<>();
        for (MobEffectInstance effect : mc.player.getActiveEffects()) {
            Identifier effectId = effect.getEffect().unwrapKey().orElseThrow().identifier();
            MobEffectInstance existing = unique.get(effectId);
            if (existing == null || effect.getAmplifier() > existing.getAmplifier()
                    || (effect.getAmplifier() == existing.getAmplifier() && effect.getDuration() > existing.getDuration())) {
                unique.put(effectId, effect);
            }
        }

        for (Map.Entry<Identifier, MobEffectInstance> entry : unique.entrySet()) {
            Identifier effectId = entry.getKey();
            MobEffectInstance effect = entry.getValue();
            Identifier icon = effectId.withPath(path -> "textures/mob_effect/" + path + ".png");
            boolean harmful = effect.getEffect().value().getCategory() == MobEffectCategory.HARMFUL;
            String name = englishName(effectId.getPath());
            int amplifier = effect.getAmplifier();
            if (amplifier > 0 && amplifier <= ROMAN.length) {
                name = name + " " + ROMAN[amplifier - 1];
            }

            String time;
            if (effect.isInfiniteDuration()) {
                time = "\u221E";
            } else {
                int seconds = effect.getDuration() / 20;
                time = seconds / 60 + ":" + String.format("%02d", seconds % 60);
            }
            this.cards.add(new Card(icon, name, time, harmful));
        }

        // Пример из референса — показывается только когда у игрока реально нет активных эффектов
        // (то есть при редактировании HUD/выборе позиции), 1:1 копия трёх зелий с фото.
        if (this.cards.isEmpty() && showcase(mc)) {
            this.cards.add(new Card(effectIcon("fire_resistance"), "Fire Resistance", "3:46", false));
            this.cards.add(new Card(effectIcon("absorption"), "Absorption IV", "0:46", false));
            this.cards.add(new Card(effectIcon("resistance"), "Resistance", "3:46", false));
        }
    }

    private static Identifier effectIcon(String name) {
        return Identifier.withDefaultNamespace("textures/mob_effect/" + name + ".png");
    }

    private static String englishName(String path) {
        String[] words = path.split("_");
        StringBuilder builder = new StringBuilder(path.length());
        for (int i = 0; i < words.length; i++) {
            if (words[i].isEmpty()) {
                continue;
            }
            if (i > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(words[i].charAt(0)));
            if (words[i].length() > 1) {
                builder.append(words[i].substring(1));
            }
        }
        return builder.toString();
    }
}
