package org.eloria.hud;

import net.minecraft.client.Minecraft;
import org.eloria.event.EventManager;
import org.eloria.event.EventTarget;
import org.eloria.event.events.lifecycle.FeatureToggleEvent;
import org.eloria.feature.Feature;
import org.eloria.feature.FeatureManager;
import org.eloria.feature.setting.BindSetting;
import org.eloria.menu.i18n.MenuText;
import org.eloria.utils.ColorUtil;
import org.eloria.utils.render.Theme;
import org.eloria.utils.render.Textures;
import org.eloria.utils.render.gui.MsdfFont;
import org.eloria.utils.render.gui.Render2DUtil;
import org.eloria.utils.render.gui.TextAlign;
import org.eloria.utils.render.gui.UiFontStyle;
import org.eloria.utils.render.gui.UiFonts;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public final class KeybindsElement extends HudElement {
    private static final int CHIP_BG = ColorUtil.rgba(9, 9, 12, 205);

    private static final float TITLE_SIZE = 11.0F;
    private static final float NAME_SIZE = 10.0F;

    private static final float HEADER_HEIGHT = 24.0F;
    private static final float HEADER_ICON_SIZE = 12.0F;
    private static final float ROW_HEIGHT = 21.0F;
    private static final float TOGGLE_WIDTH = 15.0F;
    private static final float TOGGLE_HEIGHT = 8.0F;
    private static final float CHIP_GAP = 3.0F;
    private static final float ROW_GAP = 3.0F;
    private static final float HEADER_GAP = 6.0F;
    private static final float CHIP_PADDING_X = 6.0F;
    private static final float CHIP_RADIUS = 7.0F;
    private static final float INNER_GAP = 4.0F;
    private static final int MAX_NAME_CHARS = 20;

    private record Row(String name, String bind, boolean enabled) {
    }

    private final List<Row> rows = new ArrayList<>();

    private boolean rowsDirty = true;
    private int lastFingerprint;
    private float lastUnit = Float.NaN;

    public KeybindsElement() {
        super("keybinds", "Keybinds");

        EventManager.subscribe(this);
    }

    @EventTarget
    public void onFeatureToggle(FeatureToggleEvent event) {
        this.rowsDirty = true;
    }

    @Override
    protected float defaultY(float unit) {
        return 120.0F * unit;
    }

    @Override
    protected void layout(Minecraft mc, float unit) {
        int fingerprint = fingerprint(mc);
        if (this.rowsDirty || fingerprint != this.lastFingerprint || unit != this.lastUnit) {
            this.rowsDirty = false;
            this.lastFingerprint = fingerprint;
            this.lastUnit = unit;
            collectRows(mc);
        }
        if (this.rows.isEmpty()) {
            this.width = 0.0F;
            this.height = 0.0F;
            return;
        }

        MsdfFont font = UiFonts.sfProDisplay();
        float nameSize = NAME_SIZE * unit;
        float letterSpacing = nameSize * UiFontStyle.MEDIUM.letterSpacingEm();

        float nameWidth = 0.0F;
        float bindWidth = 0.0F;
        for (Row row : this.rows) {
            nameWidth = Math.max(nameWidth,
                    font.measureWidth(truncate(row.name()), nameSize, letterSpacing));
            bindWidth = Math.max(bindWidth,
                    font.measureWidth(MenuText.bindCombination(row.bind()), nameSize, letterSpacing));
        }

        float leftChip = CHIP_PADDING_X * unit + TOGGLE_WIDTH * unit + INNER_GAP * unit
                + bindWidth + CHIP_PADDING_X * unit;
        float rightChip = CHIP_PADDING_X * unit + nameWidth + CHIP_PADDING_X * unit;
        float listWidth = leftChip + CHIP_GAP * unit + rightChip;

        float headerWidth = CHIP_PADDING_X * unit + HEADER_ICON_SIZE * unit
                + (INNER_GAP + 1.0F) * unit * 2.0F
                + font.measureWidth("Hotkeys", TITLE_SIZE * unit, TITLE_SIZE * unit * UiFontStyle.SEMIBOLD.letterSpacingEm())
                + CHIP_PADDING_X * unit;

        this.width = Math.max(listWidth, headerWidth);
        this.height = (HEADER_HEIGHT + HEADER_GAP + this.rows.size() * ROW_HEIGHT
                + (this.rows.size() - 1) * ROW_GAP) * unit;
    }

    @Override
    protected void draw(Minecraft mc, float unit) {
        if (this.rows.isEmpty()) {
            return;
        }

        float alpha = appearAlpha();
        MsdfFont font = UiFonts.sfProDisplay();

        // ===== ЗАГОЛОВОК: плашка с иконкой и "Hotkeys" =====
        int accent = Theme.getAccent();
        Render2DUtil.rect(this.x, this.y, this.width, HEADER_HEIGHT * unit)
                .color(ColorUtil.multiplyAlpha(tintWithAccent(CHIP_BG, accent), alpha))
                .radius(CHIP_RADIUS * unit)
                .shadow(ColorUtil.rgba(0, 0, 0, 110), 9.0F * unit)
                .blur(8.0F * unit, alpha)
                .draw();
        float headerIconSize = HEADER_ICON_SIZE * unit;
        float iconX = this.x + CHIP_PADDING_X * unit;
        Render2DUtil.texture(iconX,
                        this.y + (HEADER_HEIGHT * unit - headerIconSize) / 2.0F,
                        headerIconSize, headerIconSize, Textures.Icons.SLIDERS)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .draw();
        // Тонкая вертикальная черта между иконкой и заголовком — как на референсе
        float dividerX = iconX + headerIconSize + INNER_GAP * unit;
        Render2DUtil.rect(dividerX,
                        this.y + 5.0F * unit,
                        1.0F * unit,
                        (HEADER_HEIGHT - 10.0F) * unit)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.OUTLINES_LARGE, alpha))
                .draw();
        float titleSize = TITLE_SIZE * unit;
        Render2DUtil.text(dividerX + INNER_GAP * unit,
                        font.centeredTextY(this.y + HEADER_HEIGHT * unit / 2.0F, titleSize),
                        titleSize, "Hotkeys")
                .style(UiFontStyle.SEMIBOLD)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                .align(TextAlign.LEFT)
                .draw();

        // ===== СТРОКИ: чип [иконка устройства + клавиша] + чип [модуль] =====
        float textSize = NAME_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();

        float nameWidth = 0.0F;
        float bindWidth = 0.0F;
        for (Row row : this.rows) {
            nameWidth = Math.max(nameWidth,
                    font.measureWidth(truncate(row.name()), textSize, letterSpacing));
            bindWidth = Math.max(bindWidth,
                    font.measureWidth(MenuText.bindCombination(row.bind()), textSize, letterSpacing));
        }
        float leftChipWidth = CHIP_PADDING_X * unit + TOGGLE_WIDTH * unit + INNER_GAP * unit
                + bindWidth + CHIP_PADDING_X * unit;
        float rightChipWidth = CHIP_PADDING_X * unit + nameWidth + CHIP_PADDING_X * unit;

        float rowY = this.y + (HEADER_HEIGHT + HEADER_GAP) * unit;
        for (Row row : this.rows) {
            float rowHeight = ROW_HEIGHT * unit;
            float chipCenterY = rowY + rowHeight / 2.0F;

            // Левый чип: тумблер + клавиша
            Render2DUtil.rect(this.x, rowY, leftChipWidth, rowHeight)
                    .glass(alpha, 0.5F * unit, 8.0F * unit)
                    .radius(CHIP_RADIUS * unit)
                    .draw();
            float cursorOffset;

            // Мини-тумблер: включён — цвет темы, выключен — серый
            float toggleW = TOGGLE_WIDTH * unit;
            float toggleH = TOGGLE_HEIGHT * unit;
            float toggleX = this.x + CHIP_PADDING_X * unit;
            float toggleY = chipCenterY - toggleH / 2.0F;
            int trackColor = row.enabled() ? accent : Theme.Colors.OUTLINES_MEDIUM;
            Render2DUtil.rect(toggleX, toggleY, toggleW, toggleH)
                    .color(ColorUtil.multiplyAlpha(trackColor, row.enabled() ? alpha : alpha * 0.9F))
                    .radius(toggleH / 2.0F)
                    .draw();
            float knobSize = toggleH - 1.5F * unit;
            float knobX = row.enabled()
                    ? toggleX + toggleW - knobSize - 0.75F * unit
                    : toggleX + 0.75F * unit;
            Render2DUtil.rect(knobX, toggleY + (toggleH - knobSize) / 2.0F, knobSize, knobSize)
                    .color(ColorUtil.multiplyAlpha(ColorUtil.WHITE, alpha))
                    .radius(knobSize / 2.0F)
                    .draw();
            cursorOffset = CHIP_PADDING_X * unit + toggleW + INNER_GAP * unit;
            Render2DUtil.text(this.x + cursorOffset,
                            font.centeredTextY(chipCenterY, textSize),
                            textSize, MenuText.bindCombination(row.bind()))
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(row.enabled() ? ColorUtil.WHITE : TEXT_SUBTITLE, alpha))
                    .align(TextAlign.LEFT)
                    .draw();

            // Правый чип: название модуля
            float rightChipX = this.x + leftChipWidth + CHIP_GAP * unit;
            Render2DUtil.rect(rightChipX, rowY, rightChipWidth, rowHeight)
                    .glass(alpha, 0.5F * unit, 8.0F * unit)
                    .radius(CHIP_RADIUS * unit)
                    .draw();
            Render2DUtil.text(rightChipX + CHIP_PADDING_X * unit,
                            font.centeredTextY(chipCenterY, textSize),
                            textSize, truncate(row.name()))
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(row.enabled() ? Theme.Colors.TEXT_TITLE : TEXT_SUBTITLE, alpha))
                    .align(TextAlign.LEFT)
                    .draw();

            rowY += (ROW_HEIGHT + ROW_GAP) * unit;
        }
    }

    private static int TEXT_SUBTITLE = ColorUtil.rgba(255, 255, 255, 150);

    private static String truncate(String name) {
        if (name.length() > MAX_NAME_CHARS) {
            return name.substring(0, MAX_NAME_CHARS - 1) + "\u2026";
        }
        return name;
    }

    // Лёгкий подкрашивающий микс: ~18% акцента поверх базового цвета
    private static int tintWithAccent(int base, int accent) {
        float mix = 0.18F;
        int r = (int) ((base >> 16 & 0xFF) + ((accent >> 16 & 0xFF) - (base >> 16 & 0xFF)) * mix);
        int g = (int) ((base >> 8 & 0xFF) + ((accent >> 8 & 0xFF) - (base >> 8 & 0xFF)) * mix);
        int b = (int) ((base & 0xFF) + ((accent & 0xFF) - (base & 0xFF)) * mix);
        return ColorUtil.rgba(r, g, b, base >>> 24);
    }

    private int fingerprint(Minecraft mc) {
        int fp = showcase(mc) ? 1 : 0;
        for (Feature feature : FeatureManager.INSTANCE.getFeatures()) {
            fp = fp * 31 + feature.getName().hashCode();
            List<Integer> bindCodes = feature.getBinds();
            fp = fp * 31 + bindCodes.hashCode();
            for (int i = 0; i < bindCodes.size(); i++) {
                fp = fp * 31 + (feature.isBindVisibleAt(i) ? 1 : 0);
            }
            fp = fp * 31 + (feature.isEnabled() ? 1 : 0);
        }
        return fp;
    }

    private void collectRows(Minecraft mc) {
        this.rows.clear();
        for (Feature feature : FeatureManager.INSTANCE.getFeatures()) {
            StringJoiner binds = new StringJoiner(" + ");
            List<Integer> bindCodes = feature.getBinds();
            for (int i = 0; i < bindCodes.size(); i++) {
                int bindCode = bindCodes.get(i);
                if (bindCode != BindSetting.UNBOUND && feature.isBindVisibleAt(i)) {
                    binds.add(BindSetting.describe(bindCode));
                }
            }
            if (binds.length() > 0) {
                this.rows.add(new Row(feature.getName(), binds.toString(), feature.isEnabled()));
            }
        }
        if (this.rows.isEmpty() && showcase(mc)) {
            this.rows.add(new Row("TriggerBot", "R", true));
            this.rows.add(new Row("AimAssist", "R", false));
            this.rows.add(new Row("Arrows", "B", false));
        }
    }
}
