package org.eloria.hud;



import net.minecraft.client.Minecraft;

import net.minecraft.client.gui.GuiGraphicsExtractor;

import net.minecraft.client.model.Model;

import net.minecraft.client.model.geom.ModelPart;

import net.minecraft.client.player.AbstractClientPlayer;

import net.minecraft.client.renderer.entity.EntityRenderer;

import net.minecraft.client.renderer.entity.LivingEntityRenderer;

import net.minecraft.client.renderer.entity.state.EntityRenderState;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

import net.minecraft.resources.Identifier;

import net.minecraft.world.entity.EquipmentSlot;

import net.minecraft.world.entity.LivingEntity;

import net.minecraft.world.item.ItemStack;

import org.eloria.context.RenderContext;

import org.eloria.feature.impl.combat.aimassist.AimAssistFeature;

import org.eloria.feature.impl.combat.AuraFeature;

import org.eloria.feature.impl.combat.TriggerBotFeature;

import org.eloria.feature.impl.visual.TargetEspFeature;

import org.eloria.mixin.accessor.ModelPartAccessor;

import org.eloria.utils.ColorUtil;

import org.eloria.utils.render.Theme;
import org.eloria.utils.render.Textures;

import org.eloria.utils.render.gui.MsdfFont;

import org.eloria.utils.render.gui.PlayerHead;

import org.eloria.utils.render.gui.Render2DUtil;

import org.eloria.utils.render.gui.TextAlign;

import org.eloria.utils.render.gui.UiFontStyle;

import org.eloria.utils.render.gui.UiFonts;

import org.joml.Matrix3x2fStack;



import java.util.ArrayList;

import java.util.List;



public final class TargetElement extends HudElement {

    private static final int BAR_TRACK_COLOR = ColorUtil.rgba(255, 255, 255, 26);

    private static final int CARD_BG = ColorUtil.rgba(9, 9, 12, 205);

    private static final float ITEM_SIZE = 14.0F;

    private static final float ITEM_GAP = 4.0F;

    private static final float TEXT_SIZE = 11.0F;

    private static final float BAR_HEIGHT = 5.0F;

    private static final float BAR_INSET = 0.0F;



    // ===== ЗАДЕРЖКА УДЕРЖАНИЯ HUD ПОСЛЕ УДАРА =====

    private static final long HOLD_AFTER_HIT_MS = 1000L; // 1 секунда

    private long lastHitTime = 0L;

    private LivingEntity lastHitTarget = null;



    // ===== СИНГЛТОН ДЛЯ ДОСТУПА ИЗ ДРУГИХ МОДУЛЕЙ =====

    private static TargetElement instance;



    private record FaceIcon(Identifier texture, float u0, float v0, float u1, float v1) {

    }



    private static final EquipmentSlot[] EQUIPMENT_ORDER = {

            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,

            EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND

    };



    private record Style(

            float width,

            float height,

            float radius,

            float padding,

            float gap,

            float headSize,

            boolean showItems

    ) {

    }



    private static final Style MINI = new Style(168.0F, 54.0F, 10.0F, 7.0F, 7.0F, 38.0F, true);




    private final Style style = MINI;

    private LivingEntity target;

    private LivingEntity smoothedFor;

    private float smoothedHealth;

    private long lastFrameTime;



    private LivingEntity fadeEntity;

    private float fadeAlpha;

    private long lastFadeTime;



    public TargetElement() {

        super("target", "Target");

        instance = this;

    }



    // ===== ПУБЛИЧНЫЙ МЕТОД ДЛЯ ВЫЗОВА ИЗ ДРУГИХ МОДУЛЕЙ =====

    public static void onHit(LivingEntity target) {

        if (instance == null) return;

        if (target == null || !target.isAlive()) return;

        

        instance.lastHitTime = System.currentTimeMillis();

        instance.lastHitTarget = target;

        instance.fadeEntity = target; // сразу показываем

        instance.fadeAlpha = 1.0F; // мгновенное появление

    }



    @Override

    protected float defaultY(float unit) {

        return 340.0F * unit;

    }



    @Override

    protected void layout(Minecraft mc, float unit) {

        this.target = resolveTarget(mc);

        

        // ===== ЛОГИКА УДЕРЖАНИЯ HUD ПОСЛЕ УДАРА =====

        // Цель показывается, пока мы на неё смотрим (боимся/наводимся) и ещё

        // HOLD_AFTER_HIT_MS после того, как отвели взгляд от неё.

        if (this.target != null && this.target.isAlive()) {

            long now = System.currentTimeMillis();

            if (this.lastHitTarget != this.target) {

                // Новый захват — показываем сразу (при наводке до первого удара)

                this.lastHitTime = now;

                this.lastHitTarget = this.target;

            } else if (TargetEspFeature.isLookingAt(this.target)) {

                // Смотрим на цель (боимся/наводимся) — держим и обновляем таймер

                this.lastHitTime = now;

            } else if (now - this.lastHitTime >= HOLD_AFTER_HIT_MS) {

                // Отвели взгляд от цели больше чем на секунду — прячем, даже если модуль её держит

                this.target = null;

            }

        }

        

        // Если цель пропала, но мы били её меньше HOLD_AFTER_HIT_MS назад — держим fadeEntity

        if (this.target == null && this.lastHitTarget != null && this.lastHitTarget.isAlive()) {

            long elapsed = System.currentTimeMillis() - this.lastHitTime;

            if (elapsed < HOLD_AFTER_HIT_MS) {

                // Показываем последнюю цель ещё 1 секунду

                if (this.fadeEntity != this.lastHitTarget) {

                    this.fadeEntity = this.lastHitTarget;

                }

            } else {

                // Прошло больше 1 секунды — забываем цель

                this.lastHitTarget = null;

            }

        }

        

        if (this.target != null) {

            this.fadeEntity = this.target;

            // Обновляем lastHitTarget если есть цель

            if (this.target.isAlive()) {

                this.lastHitTarget = this.target;

            }

        }

        

        updateFade();

        if (this.fadeEntity == null || (this.target == null && this.fadeAlpha <= 0.02F)) {

            this.width = 0.0F;

            this.height = 0.0F;

            return;

        }

        this.width = this.style.width() * unit;

        this.height = this.style.height() * unit;

    }



    private void updateFade() {

        long now = System.currentTimeMillis();

        float delta = this.lastFadeTime == 0L ? 0.016F : Math.min(100L, now - this.lastFadeTime) / 1000.0F;

        this.lastFadeTime = now;

        

        float goal = this.target != null ? 1.0F : 0.0F;

        

        // Если цели нет, но мы в режиме удержания — держим альфу на 1.0

        if (this.target == null && this.lastHitTarget != null && this.lastHitTarget.isAlive()) {

            long elapsed = System.currentTimeMillis() - this.lastHitTime;

            if (elapsed < HOLD_AFTER_HIT_MS) {

                goal = 1.0F;

            }

        }

        

        float step = Math.clamp(delta * 12.0F, 0.0F, 1.0F);

        this.fadeAlpha += (goal - this.fadeAlpha) * step;

    }



    @Override

    protected void draw(Minecraft mc, float unit) {

        LivingEntity entity = this.target != null ? this.target : this.fadeEntity;

        if (entity == null) {

            return;

        }

        float alpha = this.fadeAlpha;
        int accent = Theme.getAccent();

        Render2DUtil.rect(this.x, this.y, this.width, this.height)
                .color(ColorUtil.multiplyAlpha(tintWithAccent(CARD_BG, accent), alpha))
                .radius(this.style.radius() * unit)
                .shadow(ColorUtil.rgba(0, 0, 0, 110), 9.0F * unit)
                .blur(8.0F * unit, alpha)
                .draw();

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = TEXT_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();
        float padding = this.style.padding() * unit;
        float contentX = this.x + padding;
        float contentRight = this.x + this.width - padding;
        float headSize = this.style.headSize() * unit;
        float headTop = this.y + (this.height - headSize) / 2.0F;

        drawHead(entity, contentX, headTop, headSize, alpha);

        float infoX = contentX + headSize + this.style.gap() * unit;
        float health = entity.getHealth() + entity.getAbsorptionAmount();
        String healthText = Integer.toString((int) Math.ceil(health));
        float heartSize = TEXT_SIZE * unit;
        float heartY = this.y + padding;

        // Имя слева
        float nameMaxWidth = contentRight - heartSize - infoX - healthTextWidth(font, healthText, textSize, letterSpacing)
                - this.style.gap() * unit;
        String name = font.ellipsize(entity.getName().getString(), textSize, letterSpacing, Math.max(10.0F, nameMaxWidth));
        Render2DUtil.text(infoX, font.centeredTextY(heartY + heartSize / 2.0F, textSize), textSize, name)
                .style(UiFontStyle.MEDIUM)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                .draw();

        // Здоровье + сердце справа — цвет темы
        Render2DUtil.text(contentRight - heartSize,
                        font.centeredTextY(heartY + heartSize / 2.0F, textSize),
                        textSize, healthText)
                .style(UiFontStyle.MEDIUM)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .align(TextAlign.RIGHT)
                .draw();
        Render2DUtil.texture(contentRight - heartSize, heartY, heartSize, heartSize, Textures.Icons.HEART)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .draw();

        // Броня под именем
        if (alpha >= 0.75F) {
            drawItems(mc, entity, infoX, heartY + heartSize + 4.0F * unit, unit);
        }

        // Полоска здоровья внизу карточки
        drawHealthBar(entity, health, infoX,
                this.y + this.height - padding - BAR_HEIGHT * unit,
                contentRight - infoX, unit, alpha);

    }

    private static float healthTextWidth(MsdfFont font, String text, float size, float letterSpacing) {
        return font.measureWidth(text, size, letterSpacing);
    }

    // Лёгкий подкрашивающий микс: ~18% акцента поверх базового цвета
    private static int tintWithAccent(int base, int accent) {
        float mix = 0.18F;
        int r = (int) ((base >> 16 & 0xFF) + ((accent >> 16 & 0xFF) - (base >> 16 & 0xFF)) * mix);
        int g = (int) ((base >> 8 & 0xFF) + ((accent >> 8 & 0xFF) - (base >> 8 & 0xFF)) * mix);
        int b = (int) ((base & 0xFF) + ((accent & 0xFF) - (base & 0xFF)) * mix);
        return ColorUtil.rgba(r, g, b, base >>> 24);
    }



    private void drawHead(LivingEntity entity, float x, float y, float size, float alpha) {

        float radius = size * 0.2F;

        int tint = ColorUtil.multiplyAlpha(ColorUtil.WHITE, alpha);

        if (entity instanceof AbstractClientPlayer player) {

            PlayerHead.draw(x, y, size, player.getSkin().body().texturePath(), radius, tint);

        } else {

            Render2DUtil.rect(x, y, size, size)

                    .color(ColorUtil.multiplyAlpha(Theme.Colors.OUTLINES_MEDIUM, alpha))

                    .radius(radius)

                    .draw();

            FaceIcon icon = resolveFaceIcon(entity);

            if (icon != null) {

                Render2DUtil.texture(x, y, size, size, icon.texture())

                        .managed()

                        .uv(icon.u0(), icon.v0(), icon.u1(), icon.v1())

                        .radius(radius)

                        .color(tint)

                        .draw();

            }

        }

    }



    @SuppressWarnings({"rawtypes", "unchecked"})

    private FaceIcon resolveFaceIcon(LivingEntity entity) {

        EntityRenderer renderer = Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(entity);

        EntityRenderState state = (EntityRenderState) renderer.createRenderState(entity, 1.0F);

        if (!(renderer instanceof LivingEntityRenderer livingRenderer)

                || !(state instanceof LivingEntityRenderState livingState)) {

            return null;

        }



        Identifier texture = livingRenderer.getTextureLocation(livingState);

        Model<?> model = livingRenderer.getModel();

        ModelPart root = model.root();

        var lookup = root.createPartLookup();

        ModelPart iconPart = lookup.apply("head");

        if (iconPart == null) {

            iconPart = lookup.apply("body");

        }

        if (iconPart == null) {

            iconPart = root;

        }



        FaceIcon icon = findLargestFrontFace(texture, iconPart);

        return icon != null || iconPart == root ? icon : findLargestFrontFace(texture, root);

    }



    private static FaceIcon findLargestFrontFace(Identifier texture, ModelPart part) {

        FaceIcon result = null;

        float largestArea = 0.0F;

        for (ModelPart candidate : part.getAllParts()) {

            for (ModelPart.Cube cube : ((ModelPartAccessor) (Object) candidate).eloria$getCubes()) {

                for (ModelPart.Polygon polygon : cube.polygons) {

                    if (polygon.normal().z() > -0.9F) {

                        continue;

                    }

                    float minU = Float.POSITIVE_INFINITY;

                    float minV = Float.POSITIVE_INFINITY;

                    float maxU = Float.NEGATIVE_INFINITY;

                    float maxV = Float.NEGATIVE_INFINITY;

                    for (ModelPart.Vertex vertex : polygon.vertices()) {

                        minU = Math.min(minU, vertex.u());

                        minV = Math.min(minV, vertex.v());

                        maxU = Math.max(maxU, vertex.u());

                        maxV = Math.max(maxV, vertex.v());

                    }

                    float area = (maxU - minU) * (maxV - minV);

                    if (area > largestArea) {

                        largestArea = area;

                        result = new FaceIcon(texture, minU, minV, maxU, maxV);

                    }

                }

            }

        }

        return result;

    }



    private void drawItems(Minecraft mc, LivingEntity entity, float x, float y, float unit) {

        List<ItemStack> stacks = new ArrayList<>(EQUIPMENT_ORDER.length);

        for (EquipmentSlot slot : EQUIPMENT_ORDER) {

            ItemStack stack = entity.getItemBySlot(slot);

            if (!stack.isEmpty()) {

                stacks.add(stack);

            }

        }

        if (stacks.isEmpty()) {

            return;

        }



        GuiGraphicsExtractor extractor = RenderContext.currentGuiGraphicsExtractor();

        if (extractor == null) {

            return;

        }



        Render2DUtil.flush();



        Matrix3x2fStack pose = extractor.pose();

        float guiScale = (float) mc.getWindow().getGuiScale();

        float itemSize = ITEM_SIZE * unit;

        float scale = itemSize / 16.0F;

        float itemY = Math.round(y * guiScale) / guiScale;

        float cursor = x;

        for (ItemStack stack : stacks) {

            float itemX = Math.round(cursor * guiScale) / guiScale;

            pose.pushMatrix();

            pose.translate(itemX, itemY);

            pose.scale(scale);

            extractor.item(stack, 0, 0);

            pose.popMatrix();

            cursor += itemSize + ITEM_GAP * unit;

        }

    }



    private void drawHealthBar(LivingEntity entity, float health, float x, float y, float width, float unit, float alpha) {

        float maxHealth = Math.max(1.0F, entity.getMaxHealth() + entity.getAbsorptionAmount());

        float fraction = Math.clamp(smoothHealth(entity, health) / maxHealth, 0.0F, 1.0F);



        float barHeight = BAR_HEIGHT * unit;

        Render2DUtil.rect(x, y, width, barHeight)

                .color(ColorUtil.multiplyAlpha(BAR_TRACK_COLOR, alpha))

                .radius(barHeight / 2.0F)

                .draw();



        float inset = BAR_INSET * unit;

        float fillHeight = barHeight - inset * 2.0F;

        float fillWidth = (width - inset * 2.0F) * fraction;

        if (fillWidth >= fillHeight) {

            Render2DUtil.rect(x + inset, y + inset, fillWidth, fillHeight)

                    .color(ColorUtil.multiplyAlpha(Theme.getAccent(), alpha))

                    .radius(fillHeight / 2.0F)

                    .shadow(ColorUtil.rgba(0, 0, 0, 26), 7.5F * unit)

                    .draw();

        }

    }



    private float smoothHealth(LivingEntity entity, float health) {

        long now = System.currentTimeMillis();

        float delta = this.lastFrameTime == 0L ? 0.016F : Math.min(100L, now - this.lastFrameTime) / 1000.0F;

        this.lastFrameTime = now;



        if (this.smoothedFor != entity) {

            this.smoothedFor = entity;

            this.smoothedHealth = health;

        }

        float step = Math.clamp(delta * 10.0F, 0.0F, 1.0F);

        this.smoothedHealth += (health - this.smoothedHealth) * step;

        return this.smoothedHealth;

    }



    private LivingEntity resolveTarget(Minecraft mc) {

        AuraFeature aura = AuraFeature.getMarkerFeature();

        LivingEntity current = aura != null ? aura.getCurrentTarget() : null;

        if (current == null) {

            TriggerBotFeature triggerBot = TriggerBotFeature.getEnabled();

            if (triggerBot != null) {

                current = triggerBot.getCurrentTarget();

            }

        }

        if (current == null) {

            AimAssistFeature aimAssist = AimAssistFeature.getEnabled();

            if (aimAssist != null) {

                current = aimAssist.getCurrentTarget();

            }

        }

        if (current == null && showcase(mc)) {

            current = mc.player;

        }

        return current != null && current.isAlive() ? current : null;

    }



    // ===== ГЕТТЕР ДЛЯ ДОСТУПА ИЗ AIMASSIST =====

    public LivingEntity getCurrentTarget() {

        return this.target;

    }

}


