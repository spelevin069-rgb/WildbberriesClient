package org.eloria.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import org.eloria.utils.ColorUtil;
import org.eloria.utils.render.Theme;
import org.eloria.utils.render.Textures;
import org.eloria.utils.render.gui.MsdfFont;
import org.eloria.utils.render.gui.Render2DUtil;
import org.eloria.utils.render.gui.TextAlign;
import org.eloria.utils.render.gui.UiFontStyle;
import org.eloria.utils.render.gui.UiFonts;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class WatermarkElement extends HudElement {
    private static final int CHIP_BG = ColorUtil.rgba(13, 17, 23, 210);
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT);

    private static final float HEIGHT = 26.0F;
    private static final float RADIUS = 8.0F;
    private static final float PADDING_X = 9.0F;
    private static final float BOLT_SIZE = 13.0F;
    private static final float BOLT_GAP = 10.0F;
    private static final float ICON_SIZE = 11.0F;
    private static final float ICON_TEXT_GAP = 5.0F;
    private static final float SECTION_GAP = 13.0F;
    private static final float TEXT_SIZE = 11.0F;

    private record Section(Identifier icon, String text, float width) {
    }

    private static final long LAYOUT_INTERVAL_MS = 500L;

    private final List<Section> sections = new ArrayList<>();
    private float cachedUnit = -1.0F;
    private long nextLayoutAt;

    // TPS: прирост gameTime за секунду
    private long lastTpsSampleTime;
    private long lastGameTime;
    private float tps = 20.0F;

    // BPS: дистанция за секунду
    private Vec3 lastPos;
    private long lastPosTime;
    private double bps;

    public WatermarkElement() {
        super("watermark", "Watermark");
    }

    @Override
    protected boolean preservePositionOnContentResize() {
        return true;
    }

    @Override
    protected void layout(Minecraft mc, float unit) {
        long now = System.currentTimeMillis();
        if (!this.sections.isEmpty()
                && this.cachedUnit == unit
                && now < this.nextLayoutAt) {
            applyCachedWidths(unit);
            return;
        }

        this.cachedUnit = unit;
        this.nextLayoutAt = now + LAYOUT_INTERVAL_MS;

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = TEXT_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();

        this.sections.clear();
        this.sections.add(new Section(Textures.Icons.GAMEPAD, serverAddress(mc),
                font.measureWidth(serverAddress(mc), textSize, letterSpacing)));
        this.sections.add(new Section(Textures.Icons.HARD_DRIVE, mc.getFps() + " FPS",
                font.measureWidth(mc.getFps() + " FPS", textSize, letterSpacing)));
        String latencyText = latency(mc) + " ms";
        this.sections.add(new Section(Textures.Icons.CHEVRONS_LEFT_RIGHT_ELLIPSIS, latencyText,
                font.measureWidth(latencyText, textSize, letterSpacing)));
        String tpsText = String.format(Locale.ROOT, "%.0f TPS", tps(mc));
        this.sections.add(new Section(Textures.Icons.REFRESH_CCW, tpsText,
                font.measureWidth(tpsText, textSize, letterSpacing)));
        String timeText = LocalTime.now().format(TIME_FORMAT);
        this.sections.add(new Section(Textures.Icons.CLOCK, timeText,
                font.measureWidth(timeText, textSize, letterSpacing)));
        String bpsText = String.format(Locale.ROOT, "%.1f BPS", bps(mc));
        this.sections.add(new Section(Textures.Icons.PERSON_STANDING, bpsText,
                font.measureWidth(bpsText, textSize, letterSpacing)));

        applyCachedWidths(unit);
        this.height = HEIGHT * unit;
    }

    private void applyCachedWidths(float unit) {
        float width = PADDING_X * 2.0F * unit + BOLT_SIZE * unit + BOLT_GAP * unit;
        for (int i = 0; i < this.sections.size(); i++) {
            if (i > 0) {
                width += SECTION_GAP * unit;
            }
            Section section = this.sections.get(i);
            width += (ICON_SIZE + ICON_TEXT_GAP) * unit;
            width += section.width();
        }
        this.width = width;
    }

    @Override
    protected void draw(Minecraft mc, float unit) {
        float alpha = appearAlpha();
        int accent = Theme.getAccent();

        Render2DUtil.rect(this.x, this.y, this.width, this.height)
                .color(ColorUtil.multiplyAlpha(tintWithAccent(CHIP_BG, accent), alpha))
                .radius(RADIUS * unit)
                .shadow(ColorUtil.rgba(0, 0, 0, 110), 9.0F * unit)
                .blur(8.0F * unit, alpha)
                .draw();

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = TEXT_SIZE * unit;
        float centerY = this.y + this.height / 2.0F;
        float cursor = this.x + PADDING_X * unit;

        // Молния — цвет темы
        float boltSize = BOLT_SIZE * unit;
        Render2DUtil.texture(cursor, centerY - boltSize / 2.0F, boltSize, boltSize, Textures.Logos.BOLT)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .draw();
        cursor += boltSize + BOLT_GAP * unit;

        for (int i = 0; i < this.sections.size(); i++) {
            if (i > 0) {
                cursor += SECTION_GAP * unit;
            }
            Section section = this.sections.get(i);
            float iconSize = ICON_SIZE * unit;
            Render2DUtil.texture(cursor, centerY - iconSize / 2.0F, iconSize, iconSize, section.icon())
                    .color(ColorUtil.multiplyAlpha(accent, alpha * 0.55F))
                    .draw();
            cursor += iconSize + ICON_TEXT_GAP * unit;

            Render2DUtil.text(cursor, font.centeredTextY(centerY, textSize), textSize, section.text())
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                    .draw();
            cursor += section.width();
        }
    }

    private float tps(Minecraft mc) {
        long now = System.currentTimeMillis();
        long gameTime = mc.level != null ? mc.level.getGameTime() : 0L;
        if (this.lastTpsSampleTime == 0L) {
            this.lastTpsSampleTime = now;
            this.lastGameTime = gameTime;
            return this.tps;
        }
        long elapsed = now - this.lastTpsSampleTime;
        if (elapsed >= 1000L) {
            long ticks = Math.max(0L, gameTime - this.lastGameTime);
            this.tps = (float) Math.clamp(ticks * 1000.0D / elapsed, 0.0D, 20.0D);
            this.lastTpsSampleTime = now;
            this.lastGameTime = gameTime;
        }
        return this.tps;
    }

    private double bps(Minecraft mc) {
        if (mc.player == null) {
            return this.bps;
        }
        long now = System.currentTimeMillis();
        Vec3 pos = mc.player.position();
        if (this.lastPosTime == 0L || this.lastPos == null) {
            this.lastPosTime = now;
            this.lastPos = pos;
            return this.bps;
        }
        long elapsed = now - this.lastPosTime;
        if (elapsed >= 500L) {
            double dist = pos.subtract(this.lastPos).horizontalDistance();
            this.bps = dist / (elapsed / 1000.0D);
            this.lastPosTime = now;
            this.lastPos = pos;
        }
        return this.bps;
    }

    private static String serverAddress(Minecraft mc) {
        return mc.getCurrentServer() != null ? mc.getCurrentServer().ip : "Local";
    }

    private static int latency(Minecraft mc) {
        if (mc.getConnection() == null || mc.player == null) {
            return 0;
        }
        var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info != null ? info.getLatency() : 0;
    }

    // Лёгкий подкрашивающий микс: ~18% акцента поверх базового цвета
    private static int tintWithAccent(int base, int accent) {
        float mix = 0.18F;
        int r = (int) ((base >> 16 & 0xFF) + ((accent >> 16 & 0xFF) - (base >> 16 & 0xFF)) * mix);
        int g = (int) ((base >> 8 & 0xFF) + ((accent >> 8 & 0xFF) - (base >> 8 & 0xFF)) * mix);
        int b = (int) ((base & 0xFF) + ((accent & 0xFF) - (base & 0xFF)) * mix);
        return ColorUtil.rgba(r, g, b, base >>> 24);
    }
}
