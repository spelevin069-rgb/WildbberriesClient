@Redirect(
        method = "updateMouse",
        at = @At(
                value = "INVOKE",
                target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"
        )
)
private void onChangeLookDirection(
        ClientPlayerEntity player,
        double deltaX,
        double deltaY
) {
    MouseLookEvent event = new MouseLookEvent(
            deltaX,
            deltaY,
            this.cursorDeltaX,
            this.cursorDeltaY
    );

    EVENT_BUS.post(event);

    if (!event.isCancelled()) {
        player.changeLookDirection(
                event.getDeltaX(),
                event.getDeltaY()
        );
    }
}