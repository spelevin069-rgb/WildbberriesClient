public class RotationUtils implements QuicImports {

    public static float getGCD() {
        double sensitivity = mc.options.getMouseSensitivity().getValue();
        double f = sensitivity * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }

    public static float applyGCD(float angle, float previous) {
        float gcd = getGCD();
        return previous + Math.round((angle - previous) / gcd) * gcd;
    }

}