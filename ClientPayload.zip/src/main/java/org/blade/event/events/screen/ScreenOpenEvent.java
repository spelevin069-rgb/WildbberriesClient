package org.blade.event.events.screen;

import lombok.Getter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.blade.event.CancellableEvent;

@Getter
public final class ScreenOpenEvent extends CancellableEvent {
    private Minecraft client;
    private Screen screen;

    public ScreenOpenEvent set(Minecraft client, Screen screen) {
        this.client = client;
        this.screen = screen;
        return this;
    }
}
