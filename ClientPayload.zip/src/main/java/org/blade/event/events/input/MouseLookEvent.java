package org.blade.event.events.input;

import lombok.Getter;
import lombok.Setter;
import org.blade.event.CancellableEvent;

@Getter
@Setter
public final class MouseLookEvent extends CancellableEvent {
    private double deltaX;
    private double deltaY;
    private final double cursorDeltaX;
    private final double cursorDeltaY;

    public MouseLookEvent(double deltaX, double deltaY, double cursorDeltaX, double cursorDeltaY) {
        this.deltaX = deltaX;
        this.deltaY = deltaY;
        this.cursorDeltaX = cursorDeltaX;
        this.cursorDeltaY = cursorDeltaY;
    }

    public MouseLookEvent(double deltaX, double deltaY) {
        this(deltaX, deltaY, 0.0D, 0.0D);
    }
}
