package org.blade.command.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import org.blade.command.ClientCommand;
import org.blade.feature.FeatureManager;
import org.blade.feature.impl.combat.AuraFeature;
import org.blade.utils.combat.rotations.neuro.NeuroAuraSystem;
import org.blade.utils.text.ChatUtil;

import java.util.List;

public final class NeuroCommand extends ClientCommand {

    public NeuroCommand() {
        super("neuro", "Manages Neuro rotation recording, training, and profiles", ":brain:");
    }

    @Override
    public List<String> aliases() {
        return List.of("нейро", "aura-neuro", "neurosystem");
    }

    @Override
    public void build(LiteralArgumentBuilder<Object> builder) {
        builder.executes(context -> {
            ChatUtil.usage("neuro record  •  stop [name]  •  play <name>  •  train  •  generate  •  save <name>  •  load <name>  •  clear  •  list  •  status");
            return 1;
        });

        // record
        builder.then(LiteralArgumentBuilder.literal("record").executes(context -> {
            AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
            if (aura == null) {
                ChatUtil.error("Aura feature not found!");
                return 0;
            }
            NeuroAuraSystem neuro = aura.getNeuroSystem();
            neuro.startRecording();
            neuro.setUsingNeuro(false);
            ChatUtil.success("[Neuro] Запись движений начата. Бейтесь или наводитесь на цели!");
            return 1;
        }));

        // stop
        builder.then(LiteralArgumentBuilder.<Object>literal("stop")
                .executes(context -> handleStop(context, null))
                .then(RequiredArgumentBuilder.<Object, String>argument("name", StringArgumentType.word())
                        .executes(context -> handleStop(context, StringArgumentType.getString(context, "name")))));

        // play / load
        builder.then(LiteralArgumentBuilder.<Object>literal("play")
                .then(RequiredArgumentBuilder.<Object, String>argument("name", StringArgumentType.word())
                        .executes(context -> handlePlay(StringArgumentType.getString(context, "name")))));

        builder.then(LiteralArgumentBuilder.<Object>literal("load")
                .then(RequiredArgumentBuilder.<Object, String>argument("name", StringArgumentType.word())
                        .executes(context -> handlePlay(StringArgumentType.getString(context, "name")))));

        // save
        builder.then(LiteralArgumentBuilder.<Object>literal("save")
                .then(RequiredArgumentBuilder.<Object, String>argument("name", StringArgumentType.word())
                        .executes(context -> {
                            String name = StringArgumentType.getString(context, "name");
                            AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
                            if (aura == null) return 0;
                            aura.getNeuroSystem().savePatterns(name);
                            ChatUtil.success("[Neuro] Паттерны сохранены в " + name);
                            return 1;
                        })));

        // train
        builder.then(LiteralArgumentBuilder.<Object>literal("train").executes(context -> {
            AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
            if (aura == null) return 0;
            String result = aura.getNeuroSystem().trainModel();
            ChatUtil.info("[Neuro] " + result);
            return 1;
        }));

        // generate
        builder.then(LiteralArgumentBuilder.<Object>literal("generate").executes(context -> {
            AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
            if (aura == null) return 0;
            aura.getNeuroSystem().generateBaselinePatterns();
            aura.getNeuroSystem().savePatterns("default");
            ChatUtil.success("[Neuro] Сгенерированы базовые паттерны наводки (" + aura.getNeuroSystem().getPatternCount() + " шт.)");
            return 1;
        }));

        // clear
        builder.then(LiteralArgumentBuilder.<Object>literal("clear").executes(context -> {
            AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
            if (aura == null) return 0;
            aura.getNeuroSystem().clearPatterns();
            ChatUtil.info("[Neuro] Паттерны очищены");
            return 1;
        }));

        // list
        builder.then(LiteralArgumentBuilder.<Object>literal("list").executes(context -> {
            AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
            if (aura == null) return 0;
            List<String> names = aura.getNeuroSystem().getPatternNames();
            if (names.isEmpty()) {
                ChatUtil.info("[Neuro] Нет сохраненных профилей паттернов");
            } else {
                ChatUtil.header("Профили Neuro  •  " + names.size());
                names.forEach(n -> ChatUtil.entry(":brain:", n, null));
            }
            return 1;
        }));

        // status
        builder.then(LiteralArgumentBuilder.<Object>literal("status").executes(context -> {
            AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
            if (aura == null) return 0;
            NeuroAuraSystem neuro = aura.getNeuroSystem();
            ChatUtil.header("Neuro Telemetry");
            ChatUtil.entry(":chart_with_upwards_trend:", "Статус", neuro.getStatusString());
            ChatUtil.entry(":target:", "Записано паттернов", String.valueOf(neuro.getPatternCount()));
            ChatUtil.entry(":clock1:", "За эту сессию", String.valueOf(neuro.getRecordedThisSession()));
            ChatUtil.entry(":gear:", "Текущий профиль", neuro.getCurrentPatternName() != null ? neuro.getCurrentPatternName() : "none");
            ChatUtil.entry(":speech_balloon:", "Отладка", neuro.getLastDebugMessage());
            return 1;
        }));
    }

    private int handleStop(CommandContext<Object> context, String name) {
        AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
        if (aura == null) return 0;
        NeuroAuraSystem neuro = aura.getNeuroSystem();

        if (neuro.getPatternCount() == 0) {
            ChatUtil.error("[Neuro] Нет записанных паттернов для сохранения");
            neuro.stopRecording();
            return 0;
        }

        String saveName = (name != null && !name.isBlank()) ? name : "neuro_" + System.currentTimeMillis();
        neuro.savePatterns(saveName);
        neuro.stopRecording();
        ChatUtil.success("[Neuro] Запись остановлена и сохранена как: " + saveName);
        return 1;
    }

    private int handlePlay(String name) {
        AuraFeature aura = FeatureManager.INSTANCE.getFeature(AuraFeature.class);
        if (aura == null) return 0;
        NeuroAuraSystem neuro = aura.getNeuroSystem();

        neuro.loadPatterns(name);
        neuro.setRecording(false);
        neuro.setUsingNeuro(true);
        aura.componentMode.setValue("Neuro");

        ChatUtil.success("[Neuro] Загружен профиль: " + name + " (" + neuro.getPatternCount() + " паттернов)");
        ChatUtil.info("[Neuro] Режим ротации Aura переключен на 'Neuro'");
        return 1;
    }
}
