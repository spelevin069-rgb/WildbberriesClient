package org.blade.hud;

import net.minecraft.client.Minecraft;
import org.blade.menu.i18n.MenuText;
import org.blade.utils.ColorUtil;
import org.blade.utils.render.Textures;
import org.blade.utils.render.Theme;
import org.blade.utils.render.gui.MsdfFont;
import org.blade.utils.render.gui.Render2DUtil;
import org.blade.utils.render.gui.TextAlign;
import org.blade.utils.render.gui.UiFontStyle;
import org.blade.utils.render.gui.UiFonts;

public final class CoordsElement extends HudElement {
    private static final String[] AXES = {"X", "Y", "Z"};
    private static final float TITLE_SIZE = 11.0F;
    private static final float TEXT_SIZE = 10.0F;
    private static final float HEADER_HEIGHT = 24.0F;
    private static final float HEADER_ICON_SIZE = 12.0F;
    private static final float HEADER_GAP = 6.0F;
    private static final float ROW_HEIGHT = 21.0F;
    private static final float CHIP_GAP = 3.0F;
    private static final float CHIP_PADDING_X = 7.0F;
    private static final float LABEL_GAP = 4.0F;
    private static final float CHIP_RADIUS = 7.0F;

    private final String[] values = new String[3];
    private final float[] chipWidths = new float[3];

    public CoordsElement() {
        super("coords", "Coordinates");
    }

    @Override
    protected float defaultY(float unit) {
        return 63.0F * unit;
    }

    @Override
    protected void layout(Minecraft mc, float unit) {
        this.values[0] = coordinate(mc.player.getX());
        this.values[1] = coordinate(mc.player.getY());
        this.values[2] = coordinate(mc.player.getZ());

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = TEXT_SIZE * unit;
        float spacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();
        float rowWidth = 0.0F;
        for (int i = 0; i < AXES.length; i++) {
            this.chipWidths[i] = 2.0F * CHIP_PADDING_X * unit
                    + font.measureWidth(AXES[i], textSize, spacing)
                    + LABEL_GAP * unit
                    + font.measureWidth(this.values[i], textSize, spacing);
            rowWidth += this.chipWidths[i];
        }
        rowWidth += (AXES.length - 1) * CHIP_GAP * unit;

        float titleSize = TITLE_SIZE * unit;
        float headerWidth = CHIP_PADDING_X * unit + HEADER_ICON_SIZE * unit + LABEL_GAP * unit
                + font.measureWidth(MenuText.ui("Coordinates"), titleSize,
                        titleSize * UiFontStyle.SEMIBOLD.letterSpacingEm())
                + CHIP_PADDING_X * unit;
        this.width = Math.max(rowWidth, headerWidth);
        this.height = (HEADER_HEIGHT + HEADER_GAP + ROW_HEIGHT) * unit;
    }

    @Override
    protected void draw(Minecraft mc, float unit) {
        float alpha = appearAlpha();
        int accent = Theme.getAccent();
        MsdfFont font = UiFonts.sfProDisplay();

        HudVisualStyle.panel(this.x, this.y, this.width, HEADER_HEIGHT * unit,
                CHIP_RADIUS * unit, unit, alpha);
        float iconSize = HEADER_ICON_SIZE * unit;
        float iconX = this.x + CHIP_PADDING_X * unit;
        Render2DUtil.texture(iconX,
                        this.y + (HEADER_HEIGHT * unit - iconSize) / 2.0F,
                        iconSize, iconSize, Textures.Icons.MOVE_3D)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .draw();
        float titleSize = TITLE_SIZE * unit;
        Render2DUtil.text(iconX + iconSize + LABEL_GAP * unit,
                        font.centeredTextY(this.y + HEADER_HEIGHT * unit / 2.0F, titleSize),
                        titleSize, MenuText.ui("Coordinates"))
                .style(UiFontStyle.SEMIBOLD)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                .align(TextAlign.LEFT)
                .draw();

        float textSize = TEXT_SIZE * unit;
        float spacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();
        float rowY = this.y + (HEADER_HEIGHT + HEADER_GAP) * unit;
        float centerY = rowY + ROW_HEIGHT * unit / 2.0F;
        float textY = font.centeredTextY(centerY, textSize);
        float chipX = this.x;
        for (int i = 0; i < AXES.length; i++) {
            HudVisualStyle.rowPanel(chipX, rowY, this.chipWidths[i], ROW_HEIGHT * unit,
                    CHIP_RADIUS * unit, unit, alpha);

            float textX = chipX + CHIP_PADDING_X * unit;
            Render2DUtil.text(textX, textY, textSize, AXES[i])
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(accent, alpha))
                    .draw();
            textX += font.measureWidth(AXES[i], textSize, spacing) + LABEL_GAP * unit;
            Render2DUtil.text(textX, textY, textSize, this.values[i])
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TEXT, alpha))
                    .draw();
            chipX += this.chipWidths[i] + CHIP_GAP * unit;
        }
    }

    private static String coordinate(double value) {
        return Integer.toString((int) Math.floor(value));
    }
}
