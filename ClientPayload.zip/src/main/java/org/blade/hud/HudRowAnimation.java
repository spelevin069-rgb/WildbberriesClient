package org.blade.hud;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Keeps disappearing HUD rows alive until their fade and slide have finished. */
final class HudRowAnimation<K, V> {
    private static final float DURATION_SECONDS = 0.20F;

    record Item<K, V>(K key, V value) {
    }

    static final class Entry<K, V> {
        private V value;
        private float progress;
        private boolean wanted;

        private Entry(V value) {
            this.value = value;
        }

        V value() {
            return this.value;
        }

        float visibility() {
            return smooth(this.progress);
        }
    }

    private final Map<K, Entry<K, V>> entries = new LinkedHashMap<>();
    private float headerProgress;
    private long lastFrameNanos;

    void sync(List<Item<K, V>> wantedItems) {
        long now = System.nanoTime();
        float delta = this.lastFrameNanos == 0L
                ? 1.0F / 60.0F
                : Math.clamp((now - this.lastFrameNanos) / 1_000_000_000.0F, 0.0F, 0.1F);
        this.lastFrameNanos = now;
        float step = Math.min(1.0F, delta / DURATION_SECONDS);

        for (Entry<K, V> entry : this.entries.values()) {
            entry.wanted = false;
        }
        for (Item<K, V> item : wantedItems) {
            Entry<K, V> entry = this.entries.computeIfAbsent(item.key(), key -> new Entry<>(item.value()));
            entry.value = item.value();
            entry.wanted = true;
        }

        this.headerProgress = move(this.headerProgress, wantedItems.isEmpty() ? 0.0F : 1.0F, step);
        Iterator<Entry<K, V>> iterator = this.entries.values().iterator();
        while (iterator.hasNext()) {
            Entry<K, V> entry = iterator.next();
            entry.progress = move(entry.progress, entry.wanted ? 1.0F : 0.0F, step);
            if (!entry.wanted && entry.progress <= 0.001F) {
                iterator.remove();
            }
        }
    }

    boolean active() {
        return this.headerProgress > 0.001F || !this.entries.isEmpty();
    }

    float headerVisibility() {
        return smooth(this.headerProgress);
    }

    Collection<Entry<K, V>> rows() {
        return this.entries.values();
    }

    private static float move(float current, float target, float step) {
        if (current < target) {
            return Math.min(target, current + step);
        }
        return Math.max(target, current - step);
    }

    private static float smooth(float progress) {
        return progress * progress * (3.0F - 2.0F * progress);
    }
}
