package org.blade.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.BossHealthOverlay;
import net.minecraft.client.gui.components.LerpingBossEvent;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import org.blade.feature.impl.visual.RemovalsFeature;
import org.blade.menu.i18n.MenuText;
import org.blade.menu.core.MenuConfigStore;
import org.blade.mixin.accessor.BossHealthOverlayAccessor;
import org.blade.utils.ColorUtil;
import org.blade.utils.render.Theme;
import org.blade.utils.render.Textures;
import org.blade.utils.render.gui.MsdfFont;
import org.blade.utils.render.gui.Render2DUtil;
import org.blade.utils.render.gui.TextAlign;
import org.blade.utils.render.gui.UiFontStyle;
import org.blade.utils.render.gui.UiFonts;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class WatermarkElement extends HudElement {
    public enum Alignment {
        LEFT("Слева"), CENTER("По центру"), RIGHT("Справа");

        private final String label;

        Alignment(String label) {
            this.label = label;
        }

        public String label() {
            return this.label;
        }
    }

    private static final String ALIGNMENT_KEY = "hud.watermark.alignment";
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT);

    private static final float HEIGHT = 26.0F;
    private static final float RADIUS = 8.0F;
    private static final float PADDING_X = 9.0F;
    private static final float BOLT_SIZE = 13.0F;
    private static final float BOLT_GAP = 10.0F;
    private static final float ICON_SIZE = 11.0F;
    private static final float ICON_TEXT_GAP = 5.0F;
    private static final float SECTION_GAP = 13.0F;
    private static final float TEXT_SIZE = 11.0F;

    private record Section(Identifier icon, String text, float width) {
    }

    private static final long LAYOUT_INTERVAL_MS = 500L;

    private final List<Section> sections = new ArrayList<>();
    private float cachedUnit = -1.0F;
    private long nextLayoutAt;

    // TPS: прирост gameTime за секунду
    private long lastTpsSampleTime;
    private long lastGameTime;
    private float tps = 20.0F;

    // BPS: дистанция за секунду
    private Vec3 lastPos;
    private long lastPosTime;
    private double bps;
    private Alignment alignment;
    private float bossBarOffsetY;
    private long lastBossBarUpdateNanos;

    public WatermarkElement() {
        super("watermark", "Watermark");
        String saved = MenuConfigStore.getString(ALIGNMENT_KEY, Alignment.LEFT.name());
        try {
            this.alignment = Alignment.valueOf(saved);
        } catch (IllegalArgumentException exception) {
            this.alignment = Alignment.LEFT;
        }
    }

    public Alignment alignment() {
        return this.alignment;
    }

    public void setAlignment(Alignment alignment) {
        this.alignment = alignment;
        MenuConfigStore.save(data -> data.addProperty(ALIGNMENT_KEY, alignment.name()));
    }

    public boolean containsRendered(float mouseX, float mouseY) {
        float renderedY = interactionY();
        return mouseX >= this.x && mouseX <= this.x + this.width
                && mouseY >= renderedY && mouseY <= renderedY + this.height;
    }

    @Override
    protected boolean horizontalPositionLocked() {
        return true;
    }

    @Override
    protected float interactionY() {
        return this.y + this.bossBarOffsetY;
    }

    @Override
    protected boolean preservePositionOnContentResize() {
        return true;
    }

    @Override
    protected void layout(Minecraft mc, float unit) {
        long now = System.currentTimeMillis();
        if (!this.sections.isEmpty()
                && this.cachedUnit == unit
                && now < this.nextLayoutAt) {
            applyCachedWidths(unit);
            return;
        }

        this.cachedUnit = unit;
        this.nextLayoutAt = now + LAYOUT_INTERVAL_MS;

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = TEXT_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();

        this.sections.clear();
        String server = serverAddress(mc);
        this.sections.add(new Section(Textures.Icons.GAMEPAD, server,
                font.measureWidth(server, textSize, letterSpacing)));
        this.sections.add(new Section(Textures.Icons.HARD_DRIVE, mc.getFps() + " FPS",
                font.measureWidth(mc.getFps() + " FPS", textSize, letterSpacing)));
        String latencyText = latency(mc) + " ms";
        this.sections.add(new Section(Textures.Icons.CHEVRONS_LEFT_RIGHT_ELLIPSIS, latencyText,
                font.measureWidth(latencyText, textSize, letterSpacing)));
        String tpsText = String.format(Locale.ROOT, "%.0f TPS", tps(mc));
        this.sections.add(new Section(Textures.Icons.REFRESH_CCW, tpsText,
                font.measureWidth(tpsText, textSize, letterSpacing)));
        String timeText = LocalTime.now().format(TIME_FORMAT);
        this.sections.add(new Section(Textures.Icons.CLOCK, timeText,
                font.measureWidth(timeText, textSize, letterSpacing)));
        String bpsText = String.format(Locale.ROOT, "%.1f BPS", bps(mc));
        this.sections.add(new Section(Textures.Icons.PERSON_STANDING, bpsText,
                font.measureWidth(bpsText, textSize, letterSpacing)));

        applyCachedWidths(unit);
        this.height = HEIGHT * unit;
    }

    private void applyCachedWidths(float unit) {
        float width = PADDING_X * 2.0F * unit + BOLT_SIZE * unit + BOLT_GAP * unit;
        for (int i = 0; i < this.sections.size(); i++) {
            if (i > 0) {
                width += SECTION_GAP * unit;
            }
            Section section = this.sections.get(i);
            if (section.icon() != null) {
                width += (ICON_SIZE + ICON_TEXT_GAP) * unit;
            }
            width += section.width();
        }
        this.width = width;
    }

    @Override
    protected void draw(Minecraft mc, float unit) {
        float screenWidth = mc.getWindow().getGuiScaledWidth();
        float edge = Math.min(20.0F * unit, Math.max(0.0F, (screenWidth - this.width) / 2.0F));
        this.x = switch (this.alignment) {
            case LEFT -> edge;
            case CENTER -> Math.max(0.0F, (screenWidth - this.width) / 2.0F);
            case RIGHT -> Math.max(0.0F, screenWidth - this.width - edge);
        };
        updateBossBarOffset(mc, unit);
        float drawY = interactionY();
        float alpha = appearAlpha();
        int accent = Theme.getAccent();

        HudVisualStyle.panel(this.x, drawY, this.width, this.height,
                RADIUS * unit, unit, alpha);

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = TEXT_SIZE * unit;
        float centerY = drawY + this.height / 2.0F;
        float cursor = this.x + PADDING_X * unit;

        // Молния — цвет темы
        float boltSize = BOLT_SIZE * unit;
        Render2DUtil.texture(cursor, centerY - boltSize / 2.0F, boltSize, boltSize, Textures.Logos.CLIENT)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .draw();
        cursor += boltSize + BOLT_GAP * unit;

        for (int i = 0; i < this.sections.size(); i++) {
            if (i > 0) {
                cursor += SECTION_GAP * unit;
            }
            Section section = this.sections.get(i);
            if (section.icon() != null) {
                float iconSize = ICON_SIZE * unit;
                Render2DUtil.texture(cursor, centerY - iconSize / 2.0F, iconSize, iconSize, section.icon())
                        .color(ColorUtil.multiplyAlpha(accent, alpha * 0.55F))
                        .draw();
                cursor += iconSize + ICON_TEXT_GAP * unit;
            }

            Render2DUtil.text(cursor, font.centeredTextY(centerY, textSize), textSize, section.text())
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                    .draw();
            cursor += section.width();
        }
    }

    private void updateBossBarOffset(Minecraft mc, float unit) {
        long now = System.nanoTime();
        float deltaSeconds = this.lastBossBarUpdateNanos == 0L
                ? 0.0F : Math.clamp((now - this.lastBossBarUpdateNanos) / 1_000_000_000.0F, 0.0F, 0.1F);
        this.lastBossBarUpdateNanos = now;
        float target = isDragging() ? 0.0F : bossBarTargetOffset(mc, unit);
        float factor = 1.0F - (float) Math.exp(-10.0F * deltaSeconds);
        this.bossBarOffsetY += (target - this.bossBarOffsetY) * factor;
        if (Math.abs(target - this.bossBarOffsetY) < 0.05F) {
            this.bossBarOffsetY = target;
        }
    }

    private float bossBarTargetOffset(Minecraft mc, float unit) {
        if (RemovalsFeature.shouldRemoveBossBar()) {
            return 0.0F;
        }
        BossHealthOverlay overlay = mc.gui.hud.getBossOverlay();
        if (overlay == null) {
            return 0.0F;
        }
        var events = ((BossHealthOverlayAccessor) overlay).blade$getEvents();
        if (events.isEmpty()) {
            return 0.0F;
        }

        float screenWidth = mc.getWindow().getGuiScaledWidth();
        float screenHeight = mc.getWindow().getGuiScaledHeight();
        float barY = 12.0F;
        float bottom = 0.0F;
        boolean overlaps = false;
        for (LerpingBossEvent event : events.values()) {
            float titleHalfWidth = mc.font.width(event.getName()) / 2.0F;
            float left = screenWidth / 2.0F - Math.max(91.0F, titleHalfWidth);
            float right = screenWidth / 2.0F + Math.max(91.0F, titleHalfWidth);
            float top = barY - 9.0F;
            float barBottom = barY + 5.0F;
            if (this.x < right && this.x + this.width > left
                    && this.y < barBottom && this.y + this.height > top) {
                overlaps = true;
            }
            bottom = barBottom;
            barY += 19.0F;
            if (barY >= screenHeight / 3.0F) {
                break;
            }
        }
        if (!overlaps) {
            return 0.0F;
        }
        float desired = Math.max(0.0F, bottom + 7.0F * unit - this.y);
        return Math.min(desired, Math.max(0.0F, screenHeight - this.height - this.y));
    }

    private float tps(Minecraft mc) {
        long now = System.currentTimeMillis();
        long gameTime = mc.level != null ? mc.level.getGameTime() : 0L;
        if (this.lastTpsSampleTime == 0L) {
            this.lastTpsSampleTime = now;
            this.lastGameTime = gameTime;
            return this.tps;
        }
        long elapsed = now - this.lastTpsSampleTime;
        if (elapsed >= 1000L) {
            long ticks = Math.max(0L, gameTime - this.lastGameTime);
            this.tps = (float) Math.clamp(ticks * 1000.0D / elapsed, 0.0D, 20.0D);
            this.lastTpsSampleTime = now;
            this.lastGameTime = gameTime;
        }
        return this.tps;
    }

    private double bps(Minecraft mc) {
        if (mc.player == null) {
            return this.bps;
        }
        long now = System.currentTimeMillis();
        Vec3 pos = mc.player.position();
        if (this.lastPosTime == 0L || this.lastPos == null) {
            this.lastPosTime = now;
            this.lastPos = pos;
            return this.bps;
        }
        long elapsed = now - this.lastPosTime;
        if (elapsed >= 500L) {
            double dist = pos.subtract(this.lastPos).horizontalDistance();
            this.bps = dist / (elapsed / 1000.0D);
            this.lastPosTime = now;
            this.lastPos = pos;
        }
        return this.bps;
    }

    private static String serverAddress(Minecraft mc) {
        return mc.getCurrentServer() != null ? mc.getCurrentServer().ip : MenuText.ui("Singleplayer");
    }

    private static int latency(Minecraft mc) {
        if (mc.getConnection() == null || mc.player == null) {
            return 0;
        }
        var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info != null ? info.getLatency() : 0;
    }

}

