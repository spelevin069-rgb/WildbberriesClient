package org.blade.hud;

import net.minecraft.client.Minecraft;
import org.blade.utils.ColorUtil;
import org.blade.utils.render.Theme;
import org.blade.utils.render.gui.Render2DUtil;
import org.blade.utils.render.gui.TextAlign;
import org.blade.utils.render.gui.UiFontStyle;
import org.blade.utils.render.gui.UiFonts;

public final class WatermarkAlignmentModal {
    private static final float WIDTH = 330.0F;
    private static final float HEIGHT = 156.0F;
    private static final float PADDING = 17.0F;
    private static final float CARD_GAP = 7.0F;
    private static final float CARD_Y = 77.0F;
    private static final float CARD_HEIGHT = 57.0F;

    private final WatermarkElement watermark;
    private boolean open;
    private long openedAt;
    private float x;
    private float y;
    private float width;

    public WatermarkAlignmentModal(WatermarkElement watermark) {
        this.watermark = watermark;
    }

    public boolean isOpen() {
        return this.open;
    }

    public void open() {
        this.open = true;
        this.openedAt = System.currentTimeMillis();
    }

    public void close() {
        this.open = false;
    }

    public void render(Minecraft mc) {
        if (!this.open) {
            return;
        }
        float screenWidth = mc.getWindow().getGuiScaledWidth();
        float screenHeight = mc.getWindow().getGuiScaledHeight();
        this.width = Math.min(WIDTH, Math.max(220.0F, screenWidth - 24.0F));
        this.x = (screenWidth - this.width) / 2.0F;
        this.y = (screenHeight - HEIGHT) / 2.0F;
        float progress = Math.clamp((System.currentTimeMillis() - this.openedAt) / 170.0F, 0.0F, 1.0F);
        float alpha = progress * progress * (3.0F - 2.0F * progress);
        float drawY = this.y + (1.0F - alpha) * 7.0F;
        float mouseX = (float) mc.mouseHandler.getScaledXPos(mc.getWindow());
        float mouseY = (float) mc.mouseHandler.getScaledYPos(mc.getWindow());

        Render2DUtil.rect(0.0F, 0.0F, screenWidth, screenHeight)
                .color(ColorUtil.rgba(0, 0, 0, Math.round(115.0F * alpha)))
                .draw();
        Render2DUtil.rect(this.x, drawY, this.width, HEIGHT)
                .color(ColorUtil.TRANSPARENT).radius(12.0F)
                .shadow(ColorUtil.multiplyAlpha(Theme.Colors.POPUP_SHADOW, alpha), 14.0F)
                .draw();
        Render2DUtil.rect(this.x, drawY, this.width, HEIGHT)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.BACKGROUND_PRIMARY_50, alpha))
                .radius(12.0F)
                .border(0.7F, ColorUtil.multiplyAlpha(Theme.Colors.OUTLINES_LARGE, alpha))
                .blur(8.0F, alpha)
                .draw();

        drawText(this.x + PADDING, drawY + 17.0F, 14.0F, "Watermark", UiFontStyle.SEMIBOLD,
                Theme.Colors.TEXT_TITLE, alpha, TextAlign.LEFT);
        drawText(this.x + this.width - PADDING, drawY + 17.0F, 15.0F, "×", UiFontStyle.REGULAR,
                Theme.Colors.SECONDARY, alpha, TextAlign.RIGHT);
        drawText(this.x + PADDING, drawY + 45.0F, 10.0F, "Расположение на экране", UiFontStyle.MEDIUM,
                Theme.Colors.SECONDARY, alpha, TextAlign.LEFT);

        float cardWidth = (this.width - PADDING * 2.0F - CARD_GAP * 2.0F) / 3.0F;
        WatermarkElement.Alignment[] values = WatermarkElement.Alignment.values();
        for (int i = 0; i < values.length; i++) {
            WatermarkElement.Alignment option = values[i];
            float cardX = this.x + PADDING + i * (cardWidth + CARD_GAP);
            float cardY = drawY + CARD_Y;
            boolean selected = this.watermark.alignment() == option;
            boolean hovered = inside(mouseX, mouseY, cardX, cardY, cardWidth, CARD_HEIGHT);
            int background = selected ? ColorUtil.withAlpha(Theme.getAccent(), 35)
                    : hovered ? Theme.Colors.CARD_HOVER : Theme.Colors.CARD;
            int border = selected ? ColorUtil.withAlpha(Theme.getAccent(), 155)
                    : Theme.Colors.OUTLINES_MEDIUM;
            Render2DUtil.rect(cardX, cardY, cardWidth, CARD_HEIGHT)
                    .color(ColorUtil.multiplyAlpha(background, alpha))
                    .radius(8.0F)
                    .border(0.7F, ColorUtil.multiplyAlpha(border, alpha))
                    .draw();
            drawAlignmentGlyph(cardX, cardY, cardWidth, option, selected, alpha);
            drawText(cardX + cardWidth / 2.0F, cardY + 39.0F, 10.5F, option.label(),
                    UiFontStyle.MEDIUM, selected ? Theme.Colors.TEXT_TITLE : Theme.Colors.TEXT_TEXT,
                    alpha, TextAlign.CENTER);
        }
    }

    public boolean click(float mouseX, float mouseY) {
        if (!this.open) {
            return false;
        }
        float cardWidth = (this.width - PADDING * 2.0F - CARD_GAP * 2.0F) / 3.0F;
        WatermarkElement.Alignment[] values = WatermarkElement.Alignment.values();
        for (int i = 0; i < values.length; i++) {
            float cardX = this.x + PADDING + i * (cardWidth + CARD_GAP);
            if (inside(mouseX, mouseY, cardX, this.y + CARD_Y, cardWidth, CARD_HEIGHT)) {
                this.watermark.setAlignment(values[i]);
                close();
                return true;
            }
        }
        if (!inside(mouseX, mouseY, this.x, this.y, this.width, HEIGHT)
                || inside(mouseX, mouseY, this.x + this.width - 39.0F, this.y + 5.0F, 32.0F, 30.0F)) {
            close();
        }
        return true;
    }

    private static void drawAlignmentGlyph(float cardX, float cardY, float cardWidth,
                                           WatermarkElement.Alignment alignment, boolean selected, float alpha) {
        float middle = cardX + cardWidth / 2.0F;
        float left = middle - 11.0F;
        int color = ColorUtil.multiplyAlpha(selected ? Theme.getAccent() : Theme.Colors.ICON_MUTED, alpha);
        for (int line = 0; line < 3; line++) {
            float lineWidth = line == 1 ? 15.0F : 22.0F;
            float lineX = switch (alignment) {
                case LEFT -> left;
                case CENTER -> middle - lineWidth / 2.0F;
                case RIGHT -> left + 22.0F - lineWidth;
            };
            Render2DUtil.rect(lineX, cardY + 12.0F + line * 5.0F, lineWidth, 2.0F)
                    .color(color).radius(1.0F).draw();
        }
    }

    private static void drawText(float x, float centerY, float size, String text, UiFontStyle style,
                                 int color, float alpha, TextAlign align) {
        Render2DUtil.text(x, UiFonts.sfProDisplay().centeredTextY(centerY, size), size, text)
                .style(style).align(align).color(ColorUtil.multiplyAlpha(color, alpha)).draw();
    }

    private static boolean inside(float mouseX, float mouseY, float x, float y, float width, float height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
