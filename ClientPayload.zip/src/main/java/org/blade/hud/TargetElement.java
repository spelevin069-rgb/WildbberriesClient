package org.blade.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.blade.context.RenderContext;
import org.blade.feature.impl.combat.AimAssistFeature;
import org.blade.feature.impl.combat.AuraFeature;
import org.blade.feature.impl.combat.TriggerBotFeature;
import org.blade.mixin.accessor.ModelPartAccessor;
import org.blade.utils.ColorUtil;
import org.blade.utils.render.Textures;
import org.blade.utils.render.Theme;
import org.blade.utils.render.gui.MsdfFont;
import org.blade.utils.render.gui.PlayerHead;
import org.blade.utils.render.gui.Render2DUtil;
import org.blade.utils.render.gui.TextAlign;
import org.blade.utils.render.gui.UiFontStyle;
import org.blade.utils.render.gui.UiFonts;
import org.joml.Matrix3x2fStack;

import java.util.ArrayList;
import java.util.List;

public final class TargetElement extends HudElement {
    private static final int BAR_TRACK_COLOR = ColorUtil.rgba(255, 255, 255, 26);

    private static final float ITEM_SIZE = 14.0F;
    private static final float ITEM_GAP = 4.0F;
    private static final float TEXT_SIZE = 11.0F;
    private static final float BAR_HEIGHT = 5.0F;
    private static final float BAR_INSET = 0.0F;
    private static final float EMPTY_ARMOR_ICON_SIZE = 8.0F;
    private static final long DAMAGE_FLASH_MS = 480L;
    private static final long DAMAGE_TRAIL_DELAY_MS = 130L;
    private static final float EXIT_SECONDS = 0.10F;

    private record FaceIcon(Identifier texture, float u0, float v0, float u1, float v1) {
    }

    private static final EquipmentSlot[] EQUIPMENT_ORDER = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
            EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND
    };

    private record Style(
            float width,
            float height,
            float radius,
            float padding,
            float gap,
            float headSize,
            boolean showItems
    ) {
    }

    private static final Style MINI = new Style(168.0F, 54.0F, 10.0F, 7.0F, 7.0F, 38.0F, true);

    private final Style style = MINI;
    private LivingEntity target;
    private LivingEntity smoothedFor;
    private float smoothedHealth;
    private float trailingHealth;
    private float observedHealth;
    private int observedHurtTime;
    private long lastFrameTime;
    private long lastDamageTime;

    private LivingEntity fadeEntity;
    private float fadeAlpha;
    private float exitOpacity = 1.0F;
    private long lastFadeTime;

    public TargetElement() {
        super("target", "Target");
    }

    @Override
    protected float defaultY(float unit) {
        return 340.0F * unit;
    }

    @Override
    protected void layout(Minecraft mc, float unit) {
        LivingEntity previousTarget = this.target;
        this.target = requestedVisible() ? resolveTarget(mc) : null;
        if (previousTarget != null && this.target == null) {
            this.exitOpacity = smooth(this.fadeAlpha);
        } else if (previousTarget == null && this.target != null && this.fadeAlpha > 0.0F) {
            this.fadeAlpha = Math.max(this.fadeAlpha, this.exitOpacity);
        }
        if (this.target != null) {
            this.fadeEntity = this.target;
        }
        updateFade();
        if (this.fadeEntity == null || (this.target == null && this.fadeAlpha <= 0.0F)) {
            this.width = 0.0F;
            this.height = 0.0F;
            return;
        }
        this.width = this.style.width() * unit;
        this.height = this.style.height() * unit;
    }

    private void updateFade() {
        long now = System.currentTimeMillis();
        float delta = this.lastFadeTime == 0L ? 0.016F : Math.min(100L, now - this.lastFadeTime) / 1000.0F;
        this.lastFadeTime = now;
        if (this.target == null) {
            this.fadeAlpha = Math.max(0.0F, this.fadeAlpha - delta / EXIT_SECONDS);
        } else {
            float step = Math.clamp(delta * 12.0F, 0.0F, 1.0F);
            this.fadeAlpha += (1.0F - this.fadeAlpha) * step;
        }
    }

    @Override
    protected void draw(Minecraft mc, float unit) {
        LivingEntity entity = this.target != null ? this.target : this.fadeEntity;
        if (entity == null) {
            return;
        }
        float visibility = smooth(this.fadeAlpha);
        float alpha = this.target != null ? visibility : this.exitOpacity;
        int accent = Theme.getAccent();
        Matrix3x2fStack pose = RenderContext.currentGuiGraphicsExtractor().pose();
        pose.pushMatrix();
        pose.translate(0.0F, (1.0F - visibility) * 14.0F * unit);
        try {
            drawContent(mc, unit, entity, alpha, accent);
        } finally {
            pose.popMatrix();
        }
    }

    private static float smooth(float progress) {
        return progress * progress * (3.0F - 2.0F * progress);
    }

    private void drawContent(Minecraft mc, float unit, LivingEntity entity, float alpha, int accent) {
        HudVisualStyle.panel(this.x, this.y, this.width, this.height,
                this.style.radius() * unit, unit, alpha);

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = TEXT_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();
        float padding = this.style.padding() * unit;
        float contentX = this.x + padding;
        float contentRight = this.x + this.width - padding;
        float headSize = this.style.headSize() * unit;
        float headTop = this.y + (this.height - headSize) / 2.0F;
        float infoX = contentX + headSize + this.style.gap() * unit;
        float health = entity.getHealth() + entity.getAbsorptionAmount();
        updateHealthAnimation(entity, health);
        long timeSinceDamage = this.lastDamageTime == 0L
                ? DAMAGE_FLASH_MS : Math.max(0L, System.currentTimeMillis() - this.lastDamageTime);
        float damagePulse = 1.0F - Math.clamp(timeSinceDamage / (float) DAMAGE_FLASH_MS, 0.0F, 1.0F);
        damagePulse *= damagePulse;
        drawHead(entity, contentX, headTop, headSize, alpha, damagePulse);

        String healthText = Integer.toString((int) Math.ceil(health));
        float heartSize = TEXT_SIZE * unit;
        float heartY = this.y + padding;
        float nameMaxWidth = contentRight - heartSize - infoX
                - font.measureWidth(healthText, textSize, letterSpacing)
                - this.style.gap() * unit;
        String name = font.ellipsize(entity.getName().getString(), textSize, letterSpacing,
                Math.max(10.0F, nameMaxWidth));
        Render2DUtil.text(infoX, font.centeredTextY(heartY + heartSize / 2.0F, textSize), textSize, name)
                .style(UiFontStyle.MEDIUM)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                .draw();
        Render2DUtil.text(contentRight - heartSize,
                        font.centeredTextY(heartY + heartSize / 2.0F, textSize), textSize, healthText)
                .style(UiFontStyle.MEDIUM)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .align(TextAlign.RIGHT)
                .draw();
        Render2DUtil.texture(contentRight - heartSize, heartY, heartSize, heartSize, Textures.Icons.HEART)
                .color(ColorUtil.multiplyAlpha(accent, alpha))
                .draw();

        if (alpha >= 0.75F) {
            drawItems(mc, entity, infoX, heartY + heartSize + 4.0F * unit, unit, alpha);
        }
        drawHealthBar(entity, health, infoX, this.y + this.height - padding - BAR_HEIGHT * unit,
                contentRight - infoX, unit, alpha);
    }

    private void drawHead(LivingEntity entity, float x, float y, float size, float alpha, float damagePulse) {
        float radius = size * 0.2F;
        int tint = ColorUtil.multiplyAlpha(
                ColorUtil.lerp(ColorUtil.WHITE, Theme.Colors.SYSTEM_RED, damagePulse * 0.78F), alpha);
        if (entity instanceof AbstractClientPlayer player) {
            PlayerHead.draw(x, y, size, player.getSkin().body().texturePath(), radius, tint);
        } else {
            Render2DUtil.rect(x, y, size, size)
                    .color(ColorUtil.multiplyAlpha(Theme.Colors.OUTLINES_MEDIUM, alpha))
                    .radius(radius)
                    .draw();
            FaceIcon icon = resolveFaceIcon(entity);
            if (icon != null) {
                Render2DUtil.texture(x, y, size, size, icon.texture())
                        .managed()
                        .uv(icon.u0(), icon.v0(), icon.u1(), icon.v1())
                        .radius(radius)
                        .color(tint)
                        .draw();
            }
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private FaceIcon resolveFaceIcon(LivingEntity entity) {
        EntityRenderer renderer = Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(entity);
        EntityRenderState state = (EntityRenderState) renderer.createRenderState(entity, 1.0F);
        if (!(renderer instanceof LivingEntityRenderer livingRenderer)
                || !(state instanceof LivingEntityRenderState livingState)) {
            return null;
        }

        Identifier texture = livingRenderer.getTextureLocation(livingState);
        Model<?> model = livingRenderer.getModel();
        ModelPart root = model.root();
        var lookup = root.createPartLookup();
        ModelPart iconPart = lookup.apply("head");
        if (iconPart == null) {
            iconPart = lookup.apply("body");
        }
        if (iconPart == null) {
            iconPart = root;
        }

        FaceIcon icon = findLargestFrontFace(texture, iconPart);
        return icon != null || iconPart == root ? icon : findLargestFrontFace(texture, root);
    }

    private static FaceIcon findLargestFrontFace(Identifier texture, ModelPart part) {
        FaceIcon result = null;
        float largestArea = 0.0F;
        for (ModelPart candidate : part.getAllParts()) {
            for (ModelPart.Cube cube : ((ModelPartAccessor) (Object) candidate).blade$getCubes()) {
                for (ModelPart.Polygon polygon : cube.polygons) {
                    if (polygon.normal().z() > -0.9F) {
                        continue;
                    }
                    float minU = Float.POSITIVE_INFINITY;
                    float minV = Float.POSITIVE_INFINITY;
                    float maxU = Float.NEGATIVE_INFINITY;
                    float maxV = Float.NEGATIVE_INFINITY;
                    for (ModelPart.Vertex vertex : polygon.vertices()) {
                        minU = Math.min(minU, vertex.u());
                        minV = Math.min(minV, vertex.v());
                        maxU = Math.max(maxU, vertex.u());
                        maxV = Math.max(maxV, vertex.v());
                    }
                    float area = (maxU - minU) * (maxV - minV);
                    if (area > largestArea) {
                        largestArea = area;
                        result = new FaceIcon(texture, minU, minV, maxU, maxV);
                    }
                }
            }
        }
        return result;
    }

    private void drawItems(Minecraft mc, LivingEntity entity, float x, float y, float unit, float alpha) {
        List<ItemStack> stacks = new ArrayList<>(EQUIPMENT_ORDER.length);
        boolean player = entity instanceof Player;
        for (EquipmentSlot slot : EQUIPMENT_ORDER) {
            ItemStack stack = entity.getItemBySlot(slot);
            if (!stack.isEmpty() || player && slot != EquipmentSlot.MAINHAND && slot != EquipmentSlot.OFFHAND) {
                stacks.add(stack);
            }
        }
        if (stacks.isEmpty()) {
            return;
        }

        GuiGraphicsExtractor extractor = RenderContext.currentGuiGraphicsExtractor();
        if (extractor == null) {
            return;
        }

        float itemSize = ITEM_SIZE * unit;
        float cursor = x;
        for (ItemStack stack : stacks) {
            if (stack.isEmpty()) {
                float crossSize = EMPTY_ARMOR_ICON_SIZE * unit;
                float inset = (itemSize - crossSize) / 2.0F;
                Render2DUtil.texture(cursor + inset, y + inset, crossSize, crossSize, Textures.Icons.X)
                        .color(ColorUtil.multiplyAlpha(
                                ColorUtil.lerp(Theme.Colors.ICON_MUTED, Theme.getAccent(), 0.4F), alpha))
                        .draw();
            }
            cursor += itemSize + ITEM_GAP * unit;
        }
        Render2DUtil.flush();

        Matrix3x2fStack pose = extractor.pose();
        float guiScale = (float) mc.getWindow().getGuiScale();
        float scale = itemSize / 16.0F;
        float itemY = Math.round(y * guiScale) / guiScale;
        cursor = x;
        for (ItemStack stack : stacks) {
            if (!stack.isEmpty()) {
                float itemX = Math.round(cursor * guiScale) / guiScale;
                pose.pushMatrix();
                pose.translate(itemX, itemY);
                pose.scale(scale);
                extractor.item(stack, 0, 0);
                pose.popMatrix();
            }
            cursor += itemSize + ITEM_GAP * unit;
        }
    }

    private void drawHealthBar(LivingEntity entity, float health, float x, float y, float width, float unit, float alpha) {
        float maxHealth = Math.max(1.0F, entity.getMaxHealth() + entity.getAbsorptionAmount());
        float fraction = Math.clamp(this.smoothedHealth / maxHealth, 0.0F, 1.0F);
        float trailingFraction = Math.clamp(this.trailingHealth / maxHealth, 0.0F, 1.0F);

        float barHeight = BAR_HEIGHT * unit;
        Render2DUtil.rect(x, y, width, barHeight)
                .color(ColorUtil.multiplyAlpha(BAR_TRACK_COLOR, alpha))
                .radius(barHeight / 2.0F)
                .draw();

        float inset = BAR_INSET * unit;
        float fillHeight = barHeight - inset * 2.0F;
        float trailWidth = (width - inset * 2.0F) * trailingFraction;
        float fillWidth = (width - inset * 2.0F) * fraction;
        if (trailWidth >= fillHeight && trailWidth > fillWidth) {
            Render2DUtil.rect(x + inset, y + inset, trailWidth, fillHeight)
                    .color(ColorUtil.multiplyAlpha(
                            ColorUtil.lerp(Theme.getAccent(), Theme.Colors.SYSTEM_RED, 0.45F), alpha * 0.82F))
                    .radius(fillHeight / 2.0F)
                    .draw();
        }
        if (fillWidth >= fillHeight) {
            Render2DUtil.rect(x + inset, y + inset, fillWidth, fillHeight)
                    .color(ColorUtil.multiplyAlpha(Theme.getAccent(), alpha))
                    .radius(fillHeight / 2.0F)
                    .shadow(ColorUtil.rgba(0, 0, 0, 26), 7.5F * unit)
                    .draw();
        }
    }

    private void updateHealthAnimation(LivingEntity entity, float health) {
        long now = System.currentTimeMillis();
        float delta = this.lastFrameTime == 0L ? 0.016F
                : Math.clamp((now - this.lastFrameTime) / 1000.0F, 0.0F, 0.05F);
        this.lastFrameTime = now;

        if (this.smoothedFor != entity) {
            this.smoothedFor = entity;
            this.smoothedHealth = health;
            this.trailingHealth = health;
            this.observedHealth = health;
            this.observedHurtTime = entity.hurtTime;
            this.lastDamageTime = 0L;
            return;
        }
        boolean lostHealth = health < this.observedHealth - 0.01F;
        boolean healed = health > this.observedHealth + 0.01F;
        boolean newHit = entity.hurtTime > this.observedHurtTime + 1;
        if (lostHealth || newHit) {
            this.lastDamageTime = now;
            this.trailingHealth = Math.max(this.trailingHealth, this.observedHealth);
        }
        this.observedHealth = health;
        this.observedHurtTime = entity.hurtTime;

        float foregroundStep = 1.0F - (float) Math.exp(-11.0F * delta);
        this.smoothedHealth += (health - this.smoothedHealth) * foregroundStep;
        if (healed) {
            this.trailingHealth = this.smoothedHealth;
        } else if (now - this.lastDamageTime >= DAMAGE_TRAIL_DELAY_MS) {
            float trailStep = 1.0F - (float) Math.exp(-4.0F * delta);
            this.trailingHealth += (health - this.trailingHealth) * trailStep;
        }
        this.trailingHealth = Math.max(this.trailingHealth, this.smoothedHealth);
    }

    private LivingEntity resolveTarget(Minecraft mc) {
        AuraFeature aura = AuraFeature.getMarkerFeature();
        LivingEntity current = aura != null ? aura.getCurrentTarget() : null;
        if (current == null) {
            TriggerBotFeature triggerBot = TriggerBotFeature.getEnabled();
            if (triggerBot != null) {
                current = triggerBot.getCurrentTarget();
            }
        }
        if (current == null) {
            AimAssistFeature aimAssist = AimAssistFeature.getEnabled();
            if (aimAssist != null) {
                current = aimAssist.getTarget();
            }
        }
        if (current == null && showcase(mc)) {
            current = mc.player;
        }
        return current != null && current.isAlive() ? current : null;
    }
}
