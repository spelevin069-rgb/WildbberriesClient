package org.blade.hud;

import org.blade.utils.ColorUtil;
import org.blade.utils.render.Theme;
import org.blade.utils.render.gui.Render2DUtil;

/** Shared dark HUD surface that follows the current client accent. */
final class HudVisualStyle {
    static final int BASE = ColorUtil.rgba(9, 9, 12, 205);

    private HudVisualStyle() {
    }

    static int surface(int base) {
        int accent = Theme.getAccent();
        float mix = 0.18F;
        int r = (int) ((base >> 16 & 0xFF) + ((accent >> 16 & 0xFF) - (base >> 16 & 0xFF)) * mix);
        int g = (int) ((base >> 8 & 0xFF) + ((accent >> 8 & 0xFF) - (base >> 8 & 0xFF)) * mix);
        int b = (int) ((base & 0xFF) + ((accent & 0xFF) - (base & 0xFF)) * mix);
        return ColorUtil.rgba(r, g, b, base >>> 24);
    }

    static void panel(float x, float y, float width, float height,
                      float radius, float unit, float alpha) {
        Render2DUtil.rect(x, y, width, height)
                .color(ColorUtil.multiplyAlpha(surface(BASE), alpha))
                .radius(radius)
                .shadow(ColorUtil.rgba(0, 0, 0, 110), 9.0F * unit)
                .blur(8.0F * unit, alpha)
                .draw();
    }

    static void rowPanel(float x, float y, float width, float height,
                         float radius, float unit, float alpha) {
        Render2DUtil.rect(x, y, width, height)
                .color(ColorUtil.multiplyAlpha(surface(BASE), alpha))
                .radius(radius)
                .blur(8.0F * unit, alpha)
                .draw();
    }

    static void chip(float x, float y, float width, float height, float radius, float alpha) {
        Render2DUtil.rect(x, y, width, height)
                .color(ColorUtil.multiplyAlpha(surface(BASE), alpha))
                .radius(radius)
                .shadow(ColorUtil.rgba(0, 0, 0, Math.round(95.0F * alpha)), radius)
                .draw();
    }
}
