package org.blade.hud;

import net.minecraft.client.Minecraft;
import org.blade.event.EventManager;
import org.blade.event.EventTarget;
import org.blade.event.events.lifecycle.FeatureToggleEvent;
import org.blade.feature.Feature;
import org.blade.feature.FeatureManager;
import org.blade.feature.setting.BindSetting;
import org.blade.menu.i18n.MenuText;
import org.blade.utils.ColorUtil;
import org.blade.utils.render.Theme;
import org.blade.utils.render.Textures;
import org.blade.utils.render.gui.MsdfFont;
import org.blade.utils.render.gui.Render2DUtil;
import org.blade.utils.render.gui.TextAlign;
import org.blade.utils.render.gui.UiFontStyle;
import org.blade.utils.render.gui.UiFonts;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.StringJoiner;

public final class KeybindsElement extends HudElement {

    private static final float TITLE_SIZE = 11.0F;
    private static final float NAME_SIZE = 10.0F;

    private static final float HEADER_HEIGHT = 24.0F;
    private static final float HEADER_PAD_RIGHT = 10.0F;
    private static final float HEADER_ICON_SIZE = 12.0F;
    private static final float ROW_HEIGHT = 21.0F;
    private static final float TOGGLE_WIDTH = 13.0F;
    private static final float TOGGLE_HEIGHT = 7.0F;
    private static final float CHIP_GAP = 3.0F;
    private static final float ROW_GAP = 3.0F;
    private static final float HEADER_GAP = 6.0F;
    private static final float CHIP_PADDING_X = 6.0F;
    private static final float CHIP_RADIUS = 7.0F;
    private static final float INNER_GAP = 4.0F;
    private static final float MAX_NAME_TEXT_WIDTH = 72.0F;
    private static final float MAX_BIND_TEXT_WIDTH = 50.0F;

    private record Row(String name, String bind) {
    }

    private record DisplayRow(String name, String bind, float nameWidth, float bindWidth) {
    }

    private final List<Row> rows = new ArrayList<>();
    private final HudRowAnimation<String, DisplayRow> animation = new HudRowAnimation<>();
    private final List<HudRowAnimation.Entry<String, DisplayRow>> orderedRows = new ArrayList<>();
    private float headerWidth;

    private boolean rowsDirty = true;
    private int lastFingerprint;
    private float lastUnit = Float.NaN;

    public KeybindsElement() {
        super("keybinds", "Keybinds");

        EventManager.subscribe(this);
    }

    @EventTarget
    public void onFeatureToggle(FeatureToggleEvent event) {
        this.rowsDirty = true;
    }

    @Override
    protected float defaultY(float unit) {
        return 120.0F * unit;
    }

    @Override
    protected boolean preservePositionOnContentResize() {
        return true;
    }

    @Override
    protected void layout(Minecraft mc, float unit) {
        int fingerprint = fingerprint();
        if (this.rowsDirty || fingerprint != this.lastFingerprint || unit != this.lastUnit) {
            this.rowsDirty = false;
            this.lastFingerprint = fingerprint;
            this.lastUnit = unit;
            collectRows();
        }
        MsdfFont font = UiFonts.sfProDisplay();
        float nameSize = NAME_SIZE * unit;
        float letterSpacing = nameSize * UiFontStyle.MEDIUM.letterSpacingEm();

        List<HudRowAnimation.Item<String, DisplayRow>> desired = new ArrayList<>();
        if (requestedVisible()) {
            for (Row row : this.rows) {
                String name = fitText(MenuText.featureName(row.name()), nameSize, letterSpacing,
                        MAX_NAME_TEXT_WIDTH * unit);
                String bind = fitText(MenuText.bindCombination(row.bind()), nameSize, letterSpacing,
                        MAX_BIND_TEXT_WIDTH * unit);
                desired.add(new HudRowAnimation.Item<>(row.name(),
                        new DisplayRow(name, bind,
                                textWidth(name, nameSize, letterSpacing),
                                textWidth(bind, nameSize, letterSpacing))));
            }
        }
        this.animation.sync(desired);
        this.orderedRows.clear();
        this.orderedRows.addAll(this.animation.rows());
        this.orderedRows.sort(Comparator.comparingDouble(entry -> entry.value().nameWidth()));
        if (!this.animation.active()) {
            this.width = 0.0F;
            this.height = 0.0F;
            return;
        }

        float listWidth = 0.0F;
        float rowSpace = 0.0F;
        float previousVisibility = -1.0F;
        for (HudRowAnimation.Entry<String, DisplayRow> entry : this.orderedRows) {
            DisplayRow row = entry.value();
            float leftChipWidth = CHIP_PADDING_X * unit + TOGGLE_WIDTH * unit + INNER_GAP * unit
                    + row.bindWidth() + CHIP_PADDING_X * unit;
            float rightChipWidth = CHIP_PADDING_X * unit + row.nameWidth() + CHIP_PADDING_X * unit;
            listWidth = Math.max(listWidth, leftChipWidth + CHIP_GAP * unit + rightChipWidth);
            float visibility = entry.visibility();
            if (previousVisibility >= 0.0F) {
                rowSpace += ROW_GAP * unit * Math.min(previousVisibility, visibility);
            }
            rowSpace += ROW_HEIGHT * unit * visibility;
            previousVisibility = visibility;
        }

        this.headerWidth = CHIP_PADDING_X * unit + HEADER_ICON_SIZE * unit
                + INNER_GAP * unit
                + font.measureWidth(MenuText.ui("Hotkeys"), TITLE_SIZE * unit,
                        TITLE_SIZE * unit * UiFontStyle.SEMIBOLD.letterSpacingEm())
                + HEADER_PAD_RIGHT * unit;

        this.width = Math.max(listWidth, this.headerWidth);
        this.height = HEADER_HEIGHT * unit
                + HEADER_GAP * unit * this.animation.headerVisibility()
                + rowSpace;
    }

    @Override
    protected void draw(Minecraft mc, float unit) {
        if (!this.animation.active()) {
            return;
        }

        float baseAlpha = appearAlpha();
        float headerVisibility = this.animation.headerVisibility();
        float headerAlpha = baseAlpha * headerVisibility;
        float headerX = this.x + (1.0F - headerVisibility) * 4.0F * unit;
        MsdfFont font = UiFonts.sfProDisplay();

        // ===== ЗАГОЛОВОК: плашка с иконкой и "Hotkeys" =====
        int accent = Theme.getAccent();
        HudVisualStyle.panel(headerX, this.y, this.headerWidth, HEADER_HEIGHT * unit,
                CHIP_RADIUS * unit, unit, headerAlpha);
        float headerIconSize = HEADER_ICON_SIZE * unit;
        float iconX = headerX + CHIP_PADDING_X * unit;
        Render2DUtil.texture(iconX,
                        this.y + (HEADER_HEIGHT * unit - headerIconSize) / 2.0F,
                        headerIconSize, headerIconSize, Textures.Icons.SLIDERS)
                .color(ColorUtil.multiplyAlpha(accent, headerAlpha))
                .draw();
        float titleSize = TITLE_SIZE * unit;
        Render2DUtil.text(iconX + headerIconSize + INNER_GAP * unit,
                        font.centeredTextY(this.y + HEADER_HEIGHT * unit / 2.0F, titleSize),
                        titleSize, MenuText.ui("Hotkeys"))
                .style(UiFontStyle.SEMIBOLD)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, headerAlpha))
                .align(TextAlign.LEFT)
                .draw();

        // ===== СТРОКИ: чип [иконка устройства + клавиша] + чип [модуль] =====
        float textSize = NAME_SIZE * unit;

        float rowY = this.y + (HEADER_HEIGHT + HEADER_GAP) * unit;
        float previousVisibility = -1.0F;
        for (HudRowAnimation.Entry<String, DisplayRow> entry : this.orderedRows) {
            DisplayRow row = entry.value();
            float leftChipWidth = CHIP_PADDING_X * unit + TOGGLE_WIDTH * unit + INNER_GAP * unit
                    + row.bindWidth() + CHIP_PADDING_X * unit;
            float rightChipWidth = CHIP_PADDING_X * unit + row.nameWidth() + CHIP_PADDING_X * unit;
            float visibility = entry.visibility();
            if (previousVisibility >= 0.0F) {
                rowY += ROW_GAP * unit * Math.min(previousVisibility, visibility);
            }
            float alpha = baseAlpha * visibility;
            float rowX = this.x + (1.0F - visibility) * 6.0F * unit;
            float drawY = rowY + (1.0F - visibility) * 3.0F * unit;
            float rowHeight = ROW_HEIGHT * unit;
            float chipCenterY = drawY + rowHeight / 2.0F;

            // Левый чип: тумблер + клавиша
            HudVisualStyle.rowPanel(rowX, drawY, leftChipWidth, rowHeight,
                    CHIP_RADIUS * unit, unit, alpha);
            float cursorOffset;

            // Мини-тумблер: включён — цвет темы, выключен — серый
            float toggleW = TOGGLE_WIDTH * unit;
            float toggleH = TOGGLE_HEIGHT * unit;
            float toggleX = rowX + CHIP_PADDING_X * unit;
            float toggleY = chipCenterY - toggleH / 2.0F;
            Render2DUtil.rect(toggleX, toggleY, toggleW, toggleH)
                    .color(ColorUtil.multiplyAlpha(accent, alpha))
                    .radius(toggleH / 2.0F)
                    .draw();
            float knobSize = toggleH - 1.5F * unit;
            float knobX = toggleX + toggleW - knobSize - 0.75F * unit;
            Render2DUtil.rect(knobX, toggleY + (toggleH - knobSize) / 2.0F, knobSize, knobSize)
                    .color(ColorUtil.multiplyAlpha(ColorUtil.WHITE, alpha))
                    .radius(knobSize / 2.0F)
                    .draw();
            cursorOffset = CHIP_PADDING_X * unit + toggleW + INNER_GAP * unit;
            Render2DUtil.text(rowX + cursorOffset,
                            font.centeredTextY(chipCenterY, textSize),
                            textSize, row.bind())
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(ColorUtil.WHITE, alpha))
                    .align(TextAlign.LEFT)
                    .draw();

            // Правый чип: название модуля
            float rightChipX = rowX + leftChipWidth + CHIP_GAP * unit;
            HudVisualStyle.rowPanel(rightChipX, drawY, rightChipWidth, rowHeight,
                    CHIP_RADIUS * unit, unit, alpha);
            Render2DUtil.text(rightChipX + CHIP_PADDING_X * unit,
                            font.centeredTextY(chipCenterY, textSize),
                            textSize, row.name())
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                    .align(TextAlign.LEFT)
                    .draw();

            rowY += ROW_HEIGHT * unit * visibility;
            previousVisibility = visibility;
        }
    }

    private static String fitText(String text, float size, float spacing, float maxWidth) {
        return UiFonts.getFontForText(text, UiFontStyle.MEDIUM.weight())
                .ellipsize(text, size, spacing, maxWidth);
    }

    private static float textWidth(String text, float size, float spacing) {
        return UiFonts.getFontForText(text, UiFontStyle.MEDIUM.weight())
                .measureWidth(text, size, spacing);
    }

    private int fingerprint() {
        int fp = 1;
        for (Feature feature : FeatureManager.INSTANCE.getFeatures()) {
            fp = fp * 31 + feature.getName().hashCode();
            List<Integer> bindCodes = feature.getBinds();
            fp = fp * 31 + bindCodes.hashCode();
            for (int i = 0; i < bindCodes.size(); i++) {
                fp = fp * 31 + (feature.isBindVisibleAt(i) ? 1 : 0);
            }
            fp = fp * 31 + (feature.isEnabled() ? 1 : 0);
        }
        return fp;
    }

    private void collectRows() {
        this.rows.clear();
        for (Feature feature : FeatureManager.INSTANCE.getFeatures()) {
            if (!feature.isEnabled()) {
                continue;
            }
            StringJoiner binds = new StringJoiner(" + ");
            List<Integer> bindCodes = feature.getBinds();
            for (int i = 0; i < bindCodes.size(); i++) {
                int bindCode = bindCodes.get(i);
                if (bindCode != BindSetting.UNBOUND && feature.isBindVisibleAt(i)) {
                    binds.add(BindSetting.describe(bindCode));
                }
            }
            if (binds.length() > 0) {
                this.rows.add(new Row(feature.getName(), binds.toString()));
            }
        }
    }
}

