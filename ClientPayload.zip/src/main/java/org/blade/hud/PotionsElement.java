package org.blade.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import org.blade.menu.i18n.MenuText;
import org.blade.utils.ColorUtil;
import org.blade.utils.render.Theme;
import org.blade.utils.render.gui.MsdfFont;
import org.blade.utils.render.gui.Render2DUtil;
import org.blade.utils.render.gui.TextAlign;
import org.blade.utils.render.gui.UiFontStyle;
import org.blade.utils.render.gui.UiFonts;
import org.blade.utils.render.Textures;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PotionsElement extends HudElement {
    private static final int TEXT_SUBTITLE = ColorUtil.rgba(255, 255, 255, 150);
    private static final String[] ROMAN = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private static final float TITLE_SIZE = 11.0F;
    private static final float NAME_SIZE = 10.0F;
    private static final float TIME_SIZE = 10.0F;

    private static final float HEADER_HEIGHT = 24.0F;
    private static final float HEADER_ICON_SIZE = 12.0F;
    private static final float ROW_HEIGHT = 21.0F;
    private static final float EFFECT_ICON_SIZE = 11.0F;
    private static final float CHIP_GAP = 4.0F;
    private static final float ROW_GAP = 5.0F;
    private static final float HEADER_GAP = 8.0F;
    private static final float CHIP_PADDING_X = 8.0F;
    private static final float HEADER_PAD_EXTRA = 4.0F;
    private static final float CHIP_RADIUS = 7.0F;
    private static final float INNER_GAP = 5.0F;
    private static final int MAX_NAME_CHARS = 18;

    private record Card(Identifier icon, String name, String time, boolean harmful) {
    }

    private final List<Card> cards = new ArrayList<>();
    private final HudRowAnimation<Identifier, Card> animation = new HudRowAnimation<>();

    public PotionsElement() {
        super("potions", "Potions");
    }

    @Override
    protected float defaultY(float unit) {
        return 260.0F * unit;
    }

    @Override
    protected boolean preservePositionOnContentResize() {
        return true;
    }

    @Override
    protected void layout(Minecraft mc, float unit) {
        if (requestedVisible()) {
            collectCards(mc);
        } else {
            this.cards.clear();
        }
        List<HudRowAnimation.Item<Identifier, Card>> desired = new ArrayList<>(this.cards.size());
        for (Card card : this.cards) {
            desired.add(new HudRowAnimation.Item<>(card.icon(), card));
        }
        this.animation.sync(desired);
        if (!this.animation.active()) {
            this.width = 0.0F;
            this.height = 0.0F;
            return;
        }

        MsdfFont font = UiFonts.sfProDisplay();
        float textSize = NAME_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();

        float timeWidth = 0.0F;
        float rowSpace = 0.0F;
        float previousVisibility = -1.0F;
        for (HudRowAnimation.Entry<Identifier, Card> entry : this.animation.rows()) {
            Card card = entry.value();
            timeWidth = Math.max(timeWidth,
                    font.measureWidth(card.time(), TIME_SIZE * unit, TIME_SIZE * unit * UiFontStyle.MEDIUM.letterSpacingEm()));
            float visibility = entry.visibility();
            if (previousVisibility >= 0.0F) {
                rowSpace += ROW_GAP * unit * Math.min(previousVisibility, visibility);
            }
            rowSpace += ROW_HEIGHT * unit * visibility;
            previousVisibility = visibility;
        }

        float leftChip = CHIP_PADDING_X * unit + EFFECT_ICON_SIZE * unit + INNER_GAP * unit
                + timeWidth + CHIP_PADDING_X * unit;

        float listWidth = 0.0F;
        for (HudRowAnimation.Entry<Identifier, Card> entry : this.animation.rows()) {
            float nameWidth = font.measureWidth(truncate(entry.value().name()), textSize, letterSpacing);
            float rightChip = CHIP_PADDING_X * unit + nameWidth + CHIP_PADDING_X * unit;
            listWidth = Math.max(listWidth, leftChip + CHIP_GAP * unit + rightChip);
        }

        float headerWidth = CHIP_PADDING_X * unit + HEADER_ICON_SIZE * unit + INNER_GAP * unit
                + font.measureWidth(MenuText.ui("Potions"), TITLE_SIZE * unit,
                        TITLE_SIZE * unit * UiFontStyle.SEMIBOLD.letterSpacingEm())
                + (CHIP_PADDING_X + HEADER_PAD_EXTRA) * unit;

        this.width = Math.max(listWidth, headerWidth);
        this.height = HEADER_HEIGHT * unit
                + HEADER_GAP * unit * this.animation.headerVisibility()
                + rowSpace;
    }

    @Override
    protected void draw(Minecraft mc, float unit) {
        if (!this.animation.active()) {
            return;
        }

        float baseAlpha = appearAlpha();
        float headerVisibility = this.animation.headerVisibility();
        float headerAlpha = baseAlpha * headerVisibility;
        float headerX = this.x + (1.0F - headerVisibility) * 4.0F * unit;
        MsdfFont font = UiFonts.sfProDisplay();

        // ===== ЗАГОЛОВОК: плашка с иконкой колбы и "Potions", ширина только по содержимому =====
        int accent = Theme.getAccent();
        float headerWidth = CHIP_PADDING_X * unit + HEADER_ICON_SIZE * unit + INNER_GAP * unit
                + font.measureWidth(MenuText.ui("Potions"), TITLE_SIZE * unit,
                        TITLE_SIZE * unit * UiFontStyle.SEMIBOLD.letterSpacingEm())
                + (CHIP_PADDING_X + HEADER_PAD_EXTRA) * unit;
        HudVisualStyle.panel(headerX, this.y, headerWidth, HEADER_HEIGHT * unit,
                CHIP_RADIUS * unit, unit, headerAlpha);
        float headerIconSize = HEADER_ICON_SIZE * unit;
        Render2DUtil.texture(headerX + CHIP_PADDING_X * unit,
                        this.y + (HEADER_HEIGHT * unit - headerIconSize) / 2.0F,
                        headerIconSize, headerIconSize, Textures.Icons.FLASK)
                .color(ColorUtil.multiplyAlpha(accent, headerAlpha))
                .draw();
        float titleSize = TITLE_SIZE * unit;
        Render2DUtil.text(headerX + CHIP_PADDING_X * unit + headerIconSize + INNER_GAP * unit,
                        font.centeredTextY(this.y + HEADER_HEIGHT * unit / 2.0F, titleSize),
                        titleSize, MenuText.ui("Potions"))
                .style(UiFontStyle.SEMIBOLD)
                .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, headerAlpha))
                .align(TextAlign.LEFT)
                .draw();

        // ===== СТРОКИ: чип [иконка + время] + чип [название] =====
        float textSize = NAME_SIZE * unit;
        float timeSize = TIME_SIZE * unit;
        float letterSpacing = textSize * UiFontStyle.MEDIUM.letterSpacingEm();

        float timeWidth = 0.0F;
        for (HudRowAnimation.Entry<Identifier, Card> entry : this.animation.rows()) {
            Card card = entry.value();
            timeWidth = Math.max(timeWidth,
                    font.measureWidth(card.time(), timeSize, timeSize * UiFontStyle.MEDIUM.letterSpacingEm()));
        }
        float leftChipWidth = CHIP_PADDING_X * unit + EFFECT_ICON_SIZE * unit + INNER_GAP * unit
                + timeWidth + CHIP_PADDING_X * unit;

        float rowY = this.y + (HEADER_HEIGHT + HEADER_GAP) * unit;
        float previousVisibility = -1.0F;
        for (HudRowAnimation.Entry<Identifier, Card> entry : this.animation.rows()) {
            Card card = entry.value();
            float visibility = entry.visibility();
            if (previousVisibility >= 0.0F) {
                rowY += ROW_GAP * unit * Math.min(previousVisibility, visibility);
            }
            float alpha = baseAlpha * visibility;
            float rowX = this.x + (1.0F - visibility) * 6.0F * unit;
            float drawY = rowY + (1.0F - visibility) * 3.0F * unit;
            float rowHeight = ROW_HEIGHT * unit;

            // Левый чип: иконка эффекта + таймер
            HudVisualStyle.rowPanel(rowX, drawY, leftChipWidth, rowHeight,
                    CHIP_RADIUS * unit, unit, alpha);
            float iconSize = EFFECT_ICON_SIZE * unit;
            float chipCenterY = drawY + rowHeight / 2.0F;
            Render2DUtil.texture(rowX + CHIP_PADDING_X * unit, chipCenterY - iconSize / 2.0F,
                            iconSize, iconSize, card.icon())
                    .color(ColorUtil.multiplyAlpha(ColorUtil.WHITE, alpha))
                    .draw();
            float timeTextY = font.centeredTextY(chipCenterY, timeSize);
            Render2DUtil.text(rowX + CHIP_PADDING_X * unit + iconSize + INNER_GAP * unit, timeTextY,
                            timeSize, card.time())
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(card.harmful() ? Theme.Colors.SYSTEM_RED : TEXT_SUBTITLE, alpha))
                    .align(TextAlign.LEFT)
                    .draw();

            // Правый чип: название эффекта, ширина ровно по тексту
            float rightChipWidth = CHIP_PADDING_X * unit
                    + font.measureWidth(truncate(card.name()), textSize, letterSpacing)
                    + CHIP_PADDING_X * unit;
            float rightChipX = rowX + leftChipWidth + CHIP_GAP * unit;
            HudVisualStyle.rowPanel(rightChipX, drawY, rightChipWidth, rowHeight,
                    CHIP_RADIUS * unit, unit, alpha);
            Render2DUtil.text(rightChipX + CHIP_PADDING_X * unit,
                            font.centeredTextY(chipCenterY, textSize),
                            textSize, truncate(card.name()))
                    .style(UiFontStyle.MEDIUM)
                    .color(ColorUtil.multiplyAlpha(Theme.Colors.TEXT_TITLE, alpha))
                    .align(TextAlign.LEFT)
                    .draw();

            rowY += ROW_HEIGHT * unit * visibility;
            previousVisibility = visibility;
        }
    }

    private static String truncate(String name) {
        if (name.length() > MAX_NAME_CHARS) {
            return name.substring(0, MAX_NAME_CHARS - 1) + "\u2026";
        }
        return name;
    }

    private void collectCards(Minecraft mc) {
        this.cards.clear();
        Map<Identifier, MobEffectInstance> unique = new LinkedHashMap<>();
        for (MobEffectInstance effect : mc.player.getActiveEffects()) {
            Identifier effectId = effect.getEffect().unwrapKey().orElseThrow().identifier();
            MobEffectInstance existing = unique.get(effectId);
            if (existing == null || effect.getAmplifier() > existing.getAmplifier()
                    || (effect.getAmplifier() == existing.getAmplifier() && effect.getDuration() > existing.getDuration())) {
                unique.put(effectId, effect);
            }
        }

        for (Map.Entry<Identifier, MobEffectInstance> entry : unique.entrySet()) {
            Identifier effectId = entry.getKey();
            MobEffectInstance effect = entry.getValue();
            Identifier icon = effectId.withPath(path -> "textures/mob_effect/" + path + ".png");
            boolean harmful = effect.getEffect().value().getCategory() == MobEffectCategory.HARMFUL;
            String name = englishName(effectId.getPath());
            int amplifier = effect.getAmplifier();
            if (amplifier > 0 && amplifier <= ROMAN.length) {
                name = name + " " + ROMAN[amplifier - 1];
            }

            String time;
            if (effect.isInfiniteDuration()) {
                time = "\u221E";
            } else {
                int seconds = effect.getDuration() / 20;
                time = seconds / 60 + ":" + String.format("%02d", seconds % 60);
            }
            this.cards.add(new Card(icon, name, time, harmful));
        }

        // Пример из референса — показывается только когда у игрока реально нет активных эффектов
        // (то есть при редактировании HUD/выборе позиции), 1:1 копия трёх зелий с фото.
        if (this.cards.isEmpty() && showcase(mc)) {
            this.cards.add(new Card(effectIcon("fire_resistance"), "Fire Resistance", "3:46", false));
            this.cards.add(new Card(effectIcon("absorption"), "Absorption IV", "0:46", false));
            this.cards.add(new Card(effectIcon("resistance"), "Resistance", "3:46", false));
        }
    }

    private static Identifier effectIcon(String name) {
        return Identifier.withDefaultNamespace("textures/mob_effect/" + name + ".png");
    }

    private static String englishName(String path) {
        String[] words = path.split("_");
        StringBuilder builder = new StringBuilder(path.length());
        for (int i = 0; i < words.length; i++) {
            if (words[i].isEmpty()) {
                continue;
            }
            if (i > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(words[i].charAt(0)));
            if (words[i].length() > 1) {
                builder.append(words[i].substring(1));
            }
        }
        return builder.toString();
    }
}

