package org.blade.menu.ui.rows;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.blade.feature.setting.BooleanSetting;
import org.blade.menu.ui.Component;
import org.blade.menu.ui.controls.ToggleComponent;
import org.blade.utils.render.Theme;

public final class ToggleRow extends SettingRow {
    private final ToggleComponent toggle;

    public ToggleRow(BooleanSetting setting) {
        super(setting);
        this.toggle = new ToggleComponent(
                setting::getValue,
                () -> setting.setValue(!setting.getValue()),
                ToggleComponent.Style.CHECKBOX,
                Theme.Colors.CONTROL_STRONG,
                Theme.getAccent()
        );
    }

    @Override
    protected void placeControl(Component owner) {
        this.toggle.place(owner, controlX(), controlY(), controlWidth(), controlHeight())
                .style(ToggleComponent.Style.CHECKBOX, Theme.Colors.CONTROL_STRONG, controlAccent(this.setting))
                .alpha(this.rowAlpha);
    }

    @Override
    public boolean click(int mouseX, int mouseY) {
        this.host.closeOtherRows(this);
        return this.toggle.handleClick(mouseX, mouseY);
    }

    @Override
    protected void renderControl(Minecraft minecraft, GuiGraphicsExtractor guiGraphicsExtractor) {
        this.toggle.render(minecraft, guiGraphicsExtractor);
    }

    @Override
    protected int controlWidth() {
        return 14;
    }

    @Override
    protected int controlHeight() {
        return 14;
    }
}
