package org.blade.mixin.input;

import net.minecraft.client.Minecraft;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.player.LocalPlayer;
import org.blade.context.RotationContext;
import org.blade.event.EventManager;
import org.blade.event.events.input.MouseInputEvent;
import org.blade.event.events.input.MouseLookEvent;
import org.blade.feature.impl.combat.AimAssistFeature;
import org.blade.menu.core.MenuOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Shadow private double accumulatedDX;
    @Shadow private double accumulatedDY;
    @Shadow private Minecraft minecraft;
    @Shadow public abstract boolean isMouseGrabbed();

    @Inject(method = "handleAccumulatedMovement", at = @At("HEAD"))
    private void onPreHandleMovement(CallbackInfo ci) {
        if (this.isMouseGrabbed() && this.minecraft.isWindowActive()) {
            AimAssistFeature aimAssist = AimAssistFeature.getEnabled();
            if (aimAssist != null && aimAssist.shouldContinuousAim()) {
                if (this.accumulatedDX == 0.0 && this.accumulatedDY == 0.0) {
                    this.accumulatedDX = 1.0E-5;
                }
            }
        }
    }

    @Inject(method = "onButton", at = @At("HEAD"), cancellable = true)
    private void onMouseButton(long window, MouseButtonInfo buttonInfo, int action, CallbackInfo ci) {
        if (!EventManager.hasListeners(MouseInputEvent.class)) {
            return;
        }
        MouseInputEvent event = EventManager.call(new MouseInputEvent(
                window,
                buttonInfo.button(),
                action,
                buttonInfo.modifiers()
        ));
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void blockWorldScrollWhileMenuOpen(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (MenuOverlay.blocksInput()) {
            MenuOverlay.handleScroll(vertical);
            ci.cancel();
        }
    }

    @Redirect(
            method = "turnPlayer",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;turn(DD)V")
    )
    private void onTurnPlayer(LocalPlayer player, double yawDelta, double pitchDelta) {
        if (EventManager.hasListeners(MouseLookEvent.class)) {
            MouseLookEvent event = EventManager.call(new MouseLookEvent(yawDelta, pitchDelta, this.accumulatedDX, this.accumulatedDY));
            if (event.isCancelled()) {
                return;
            }
            yawDelta = event.getDeltaX();
            pitchDelta = event.getDeltaY();
        }

        if (RotationContext.onMouseTurn(yawDelta, pitchDelta)) {
            return;
        }

        player.turn(yawDelta, pitchDelta);
    }
}
