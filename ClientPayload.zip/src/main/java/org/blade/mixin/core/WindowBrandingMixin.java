package org.blade.mixin.core;

import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.platform.IconSet;
import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.PackResources;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.logging.Level;
import java.util.logging.Logger;

@Mixin(Minecraft.class)
public abstract class WindowBrandingMixin {
    @Unique
    private static final Logger BLADE$WINDOW_LOGGER = Logger.getLogger("WildbberriesClient.Window");
    @Unique
    private static final String BLADE$ICON_PATH = "/assets/blade/icon.png";
    @Unique
    private static final String BLADE$WINDOW_TITLE = "WildbberriesClient 26.2 -> @why404nur / Free Build";

    @Inject(method = "<init>", at = @At("TAIL"))
    private void blade$applyWindowIcon(CallbackInfo ci) {
        try {
            Window window = ((Minecraft) (Object) this).getWindow();
            if (window != null) {
                blade$setWindowIcon(window.handle());
                window.setTitle(BLADE$WINDOW_TITLE);
            }
        } catch (Throwable throwable) {
            BLADE$WINDOW_LOGGER.log(Level.WARNING, "Failed to apply WildbberriesClient window icon", throwable);
        }
    }

    @Inject(method = "updateTitle", at = @At("HEAD"), cancellable = true)
    private void blade$setWindowTitle(CallbackInfo ci) {
        Window window = ((Minecraft) (Object) this).getWindow();
        if (window != null) {
            window.setTitle(BLADE$WINDOW_TITLE);
        }
        ci.cancel();
    }

    @Redirect(
            method = "*",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/platform/Window;setIcon(Lnet/minecraft/server/packs/PackResources;Lcom/mojang/blaze3d/platform/IconSet;)V"
            ),
            require = 0
    )
    private void blade$replaceVanillaWindowIcon(Window window, PackResources pack, IconSet iconSet) {
        if (GLFW.glfwGetPlatform() == GLFW.GLFW_PLATFORM_WAYLAND) {
            try {
                window.setIcon(pack, iconSet);
            } catch (Throwable ignored) {
            }
            return;
        }

        try {
            blade$setWindowIcon(window.handle());
        } catch (Throwable throwable) {
            BLADE$WINDOW_LOGGER.log(Level.WARNING, "Failed to apply WildbberriesClient window icon", throwable);
            try {
                window.setIcon(pack, iconSet);
            } catch (Throwable ignored) {
            }
        }
    }

    @Unique
    private static void blade$setWindowIcon(long windowHandle) throws Exception {
        if (windowHandle == 0L) {
            return;
        }

        try (InputStream stream = WindowBrandingMixin.class.getResourceAsStream(BLADE$ICON_PATH)) {
            if (stream == null) {
                BLADE$WINDOW_LOGGER.warning("Window icon resource not found: " + BLADE$ICON_PATH);
                return;
            }

            byte[] bytes = stream.readAllBytes();
            ByteBuffer encoded = MemoryUtil.memAlloc(bytes.length);
            ByteBuffer pixels = null;
            GLFWImage.Buffer icon = null;
            try {
                encoded.put(bytes).flip();
                int[] width = new int[1];
                int[] height = new int[1];
                int[] components = new int[1];
                pixels = STBImage.stbi_load_from_memory(encoded, width, height, components, 4);
                if (pixels == null) {
                    BLADE$WINDOW_LOGGER.warning("Failed to decode window icon: " + STBImage.stbi_failure_reason());
                    return;
                }

                icon = GLFWImage.malloc(1);
                icon.get(0).set(width[0], height[0], pixels);
                GLFW.glfwSetWindowIcon(windowHandle, icon);
            } finally {
                if (icon != null) {
                    icon.free();
                }
                if (pixels != null) {
                    STBImage.stbi_image_free(pixels);
                }
                MemoryUtil.memFree(encoded);
            }
        }
    }
}
