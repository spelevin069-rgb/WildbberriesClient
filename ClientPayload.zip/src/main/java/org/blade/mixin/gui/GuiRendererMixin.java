package org.blade.mixin.gui;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.SamplerCache;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import net.minecraft.client.renderer.state.gui.GuiItemRenderState;
import org.blade.utils.render.gui.GuiPipelines;
import org.blade.utils.render.gui.GuiBackdrop;
import org.blade.menu.core.MenuOverlay;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.function.Supplier;

@Mixin(GuiRenderer.class)
public abstract class GuiRendererMixin {
    @Shadow
    @Final
    private List<?> draws;

    @Unique
    private final IntList blade$glassSplits = new IntArrayList();
    @Unique
    private boolean blade$previousElementWasGlass;
    @Unique
    private boolean blade$chatBackdropCaptured;

    @Inject(method = "prepare", at = @At("HEAD"))
    private void blade$resetGlassSplits(CallbackInfo ci) {
        this.blade$glassSplits.clear();
        this.blade$previousElementWasGlass = false;
        this.blade$chatBackdropCaptured = false;
    }

    @Inject(method = "draw", at = @At("HEAD"))
    private void blade$captureChatBackdropBeforeGui(CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (!this.blade$glassSplits.isEmpty()
                && mc.gui.screen() instanceof ChatScreen
                && !MenuOverlay.isVisible()) {
            GuiBackdrop.captureNow();
            this.blade$chatBackdropCaptured = true;
        }
    }

    @Inject(method = "addElementToMesh", at = @At("HEAD"))
    private void blade$markGlassRuns(GuiElementRenderState elementState, CallbackInfo ci) {
        boolean glass = blade$isGlassPipeline(elementState.pipeline());
        if (glass && !this.blade$previousElementWasGlass) {

            this.blade$glassSplits.add(this.draws.size());
        }
        this.blade$previousElementWasGlass = glass;
    }

    @WrapOperation(
            method = "draw",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/render/GuiRenderer;executeDrawRange(Ljava/util/function/Supplier;Lcom/mojang/blaze3d/pipeline/RenderTarget;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;II)V"
            )
    )
    private void blade$captureBackdropBeforeGlassRuns(
            GuiRenderer instance,
            Supplier<String> label,
            RenderTarget mainRenderTarget,
            GpuBufferSlice dynamicTransforms,
            int startIndex,
            int endIndex,
            Operation<Void> original
    ) {
        int cursor = startIndex;
        for (int i = 0; i < this.blade$glassSplits.size(); i++) {
            int split = this.blade$glassSplits.getInt(i);
            if (split < cursor || split >= endIndex) {
                continue;
            }
            if (split > cursor) {
                original.call(instance, label, mainRenderTarget, dynamicTransforms, cursor, split);
            }
            if (!this.blade$chatBackdropCaptured) {
                GuiBackdrop.captureNow();
            }
            cursor = split;
        }
        if (cursor < endIndex) {
            original.call(instance, label, mainRenderTarget, dynamicTransforms, cursor, endIndex);
        }
    }

    @Unique
    private static boolean blade$isGlassPipeline(RenderPipeline pipeline) {
        return pipeline == GuiPipelines.BLUR_RECT || pipeline == GuiPipelines.GLASS_SHADOW;
    }

    @WrapOperation(
            method = "submitBlitFromItemAtlas",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/systems/SamplerCache;getRepeat(Lcom/mojang/blaze3d/textures/FilterMode;)Lcom/mojang/blaze3d/textures/GpuSampler;"
            )
    )
    private GpuSampler blade$smoothDownscaledItems(
            SamplerCache cache,
            FilterMode filterMode,
            Operation<GpuSampler> original,
            @Local(argsOnly = true) GuiItemRenderState itemState
    ) {
        if (blade$isDownscaled(itemState)) {
            return original.call(cache, FilterMode.LINEAR);
        }
        return original.call(cache, filterMode);
    }

    @WrapOperation(
            method = "submitBlitFromItemAtlas",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/renderer/RenderPipelines;GUI_TEXTURED_PREMULTIPLIED_ALPHA:Lcom/mojang/blaze3d/pipeline/RenderPipeline;"
            )
    )
    private RenderPipeline blade$bicubicDownscalePipeline(
            Operation<RenderPipeline> original,
            @Local(argsOnly = true) GuiItemRenderState itemState
    ) {
        if (blade$isDownscaled(itemState)) {
            return GuiPipelines.itemDownscale(Minecraft.getInstance().getWindow().getGuiScale());
        }
        return original.call();
    }

    @Unique
    private static boolean blade$isDownscaled(GuiItemRenderState itemState) {
        return itemState.pose().m00 < 0.999F;
    }
}
