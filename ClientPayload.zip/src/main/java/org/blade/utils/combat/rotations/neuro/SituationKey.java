package org.blade.utils.combat.rotations.neuro;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;

import java.io.Serializable;
import java.util.Objects;

public class SituationKey implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String targetType;      // "player", "mob", "animal"
    private final String distanceBucket;  // "close", "medium", "far"
    private final String movementState;   // "stationary", "walking", "sprinting", "jumping"
    private final String critState;       // "crit", "nocrit"
    private final String healthState;     // "high", "medium", "low"

    public SituationKey(String targetType, String distanceBucket, String movementState, String critState, String healthState) {
        this.targetType = targetType;
        this.distanceBucket = distanceBucket;
        this.movementState = movementState;
        this.critState = critState;
        this.healthState = healthState;
    }

    public static SituationKey fromEntity(LocalPlayer player, LivingEntity target) {
        if (player == null || target == null) {
            return new SituationKey("player", "medium", "stationary", "nocrit", "high");
        }

        String targetType = (target instanceof Player) ? "player" : (target instanceof Monster) ? "mob" : "animal";

        double dist = player.getEyePosition().distanceTo(target.getEyePosition());
        String distanceBucket = dist < 2.5D ? "close" : (dist < 4.0D ? "medium" : "far");

        double speed = target.getDeltaMovement().horizontalDistance();
        String movementState;
        if (!target.onGround()) {
            movementState = "jumping";
        } else if (speed > 0.22D) {
            movementState = "sprinting";
        } else if (speed > 0.05D) {
            movementState = "walking";
        } else {
            movementState = "stationary";
        }

        boolean isCrit = player.fallDistance > 0.0F && !player.onGround();
        String critState = isCrit ? "crit" : "nocrit";

        float hpPct = target.getHealth() / Math.max(1.0F, target.getMaxHealth());
        String healthState = hpPct > 0.6F ? "high" : (hpPct > 0.3F ? "medium" : "low");

        return new SituationKey(targetType, distanceBucket, movementState, critState, healthState);
    }

    public String getTargetType() {
        return targetType;
    }

    public String getDistanceBucket() {
        return distanceBucket;
    }

    public String getMovementState() {
        return movementState;
    }

    public String getCritState() {
        return critState;
    }

    public String getHealthState() {
        return healthState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SituationKey that = (SituationKey) o;
        return Objects.equals(targetType, that.targetType) &&
                Objects.equals(distanceBucket, that.distanceBucket) &&
                Objects.equals(movementState, that.movementState) &&
                Objects.equals(critState, that.critState) &&
                Objects.equals(healthState, that.healthState);
    }

    @Override
    public int hashCode() {
        return Objects.hash(targetType, distanceBucket, movementState, critState, healthState);
    }

    @Override
    public String toString() {
        return targetType + "_" + distanceBucket + "_" + movementState + "_" + critState + "_" + healthState;
    }
}
