package org.blade.utils.combat.rotations.neuro;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.blade.context.RotationContext;
import org.blade.utils.combat.rotations.AuraRotation;
import org.blade.utils.math.Angle;

public final class NeuroRotation implements AuraRotation {
    private final NeuroAuraSystem neuroSystem;

    public NeuroRotation(NeuroAuraSystem neuroSystem) {
        this.neuroSystem = neuroSystem;
    }

    @Override
    public void tick(LocalPlayer player, LivingEntity target, Vec3 targetEyePos, boolean attackLikely) {
        if (target == null || player == null || !target.isAlive()) {
            reset();
            RotationContext.clear();
            return;
        }

        Angle angle = neuroSystem.getNeuroRotation(player, target, attackLikely);
        if (angle != null) {
            RotationContext.setRotation(angle.yaw(), angle.pitch());
        }
    }

    @Override
    public void onAttack() {
        // Can be hooked by AuraFeature during attack sequence
    }

    @Override
    public void reset() {
        if (neuroSystem != null) {
            neuroSystem.reset();
        }
    }

    public NeuroAuraSystem getNeuroSystem() {
        return neuroSystem;
    }
}
