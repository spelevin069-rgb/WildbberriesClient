package org.blade.utils.combat.rotations.neuro;

import java.io.Serializable;

public class NeuroPattern implements Serializable {
    private static final long serialVersionUID = 1L;

    private final float yaw;
    private final float pitch;
    private final double distance;
    private final long timestamp;
    private final boolean isCritical;
    private final double targetSpeed;
    private final String targetType;
    private SituationKey situationKey;

    public NeuroPattern(float yaw, float pitch, double distance, boolean isCritical,
                        double targetSpeed, String targetType) {
        this(yaw, pitch, distance, isCritical, targetSpeed, targetType, null);
    }

    public NeuroPattern(float yaw, float pitch, double distance, boolean isCritical,
                        double targetSpeed, String targetType, SituationKey situationKey) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.distance = distance;
        this.timestamp = System.currentTimeMillis();
        this.isCritical = isCritical;
        this.targetSpeed = targetSpeed;
        this.targetType = targetType;
        this.situationKey = situationKey;
    }

    public float getYaw() {
        return yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public double getDistance() {
        return distance;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public boolean isCritical() {
        return isCritical;
    }

    public double getTargetSpeed() {
        return targetSpeed;
    }

    public String getTargetType() {
        return targetType;
    }

    public SituationKey getSituationKey() {
        return situationKey;
    }

    public void setSituationKey(SituationKey situationKey) {
        this.situationKey = situationKey;
    }

    @Override
    public String toString() {
        return String.format("NeuroPattern[yaw=%.2f, pitch=%.2f, dist=%.2f, crit=%b, speed=%.2f, type=%s]",
                yaw, pitch, distance, isCritical, targetSpeed, targetType);
    }
}
