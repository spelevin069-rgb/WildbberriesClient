package org.blade.utils.combat;

import java.util.concurrent.ThreadLocalRandom;

public final class SprintManager {
    public enum ResetMode {
        W_TAP,
        S_TAP,
        PACKET
    }

    private static final long DEFAULT_HOLD_MS = 75L;
    private static final long MIN_HOLD_MS = 55L;
    private static final long MAX_HOLD_MS = 85L;

    private static long lastImminentNanos = Long.MIN_VALUE;
    private static long holdMillis = DEFAULT_HOLD_MS;
    private static ResetMode activeMode = ResetMode.W_TAP;

    private SprintManager() {
    }

    public static void markAttackImminent() {
        lastImminentNanos = System.nanoTime();
    }

    public static void onAttack() {
        onAttack(ResetMode.W_TAP);
    }

    public static void onAttack(ResetMode mode) {
        activeMode = mode != null ? mode : ResetMode.W_TAP;
        holdMillis = ThreadLocalRandom.current().nextLong(MIN_HOLD_MS, MAX_HOLD_MS + 1L);
        lastImminentNanos = System.nanoTime();
    }

    public static boolean shouldFreezeMovementInput() {
        return lastImminentNanos != Long.MIN_VALUE
                && System.nanoTime() - lastImminentNanos < holdMillis * 1_000_000L;
    }

    public static ResetMode getActiveMode() {
        return activeMode;
    }

    public static void reset() {
        lastImminentNanos = Long.MIN_VALUE;
        holdMillis = DEFAULT_HOLD_MS;
        activeMode = ResetMode.W_TAP;
    }
}
