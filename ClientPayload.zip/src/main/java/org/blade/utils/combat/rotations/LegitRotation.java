package org.blade.utils.combat.rotations;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.blade.context.RotationContext;
import org.blade.utils.math.NoiseUtil;

import java.util.LinkedList;
import java.util.concurrent.ThreadLocalRandom;

public final class LegitRotation implements AuraRotation {
    private final LinkedList<Vec3> targetPositionHistory = new LinkedList<>();
    private float remainderYaw = 0.0F;
    private float remainderPitch = 0.0F;

    @Override
    public void tick(LocalPlayer player, LivingEntity target, Vec3 targetEyePos, boolean attackLikely) {
        if (target == null || !target.isAlive()) {
            reset();
            return;
        }

        long now = System.currentTimeMillis();

        // Maintain historical positions for reaction delay (~150-200ms)
        targetPositionHistory.addLast(target.getDeltaMovement());
        while (targetPositionHistory.size() > 7) {
            targetPositionHistory.removeFirst();
        }

        // 1. Human Perceptual Latency (reaction delay buffer)
        Vec3 targetPos = target.position();
        if (!targetPositionHistory.isEmpty()) {
            int delayIndex = Math.min(2, targetPositionHistory.size() - 1);
            Vec3 historicVel = targetPositionHistory.get(delayIndex);
            targetPos = target.position().subtract(historicVel.scale(0.35D));
        }

        // 2. Wandering Aim-Point (organically float target height/offsets)
        double noiseTime = now / 450.0D;
        float wanderY = NoiseUtil.perlin1D(noiseTime) * 0.10F;
        float wanderX = NoiseUtil.perlin2D(noiseTime, 10.0D) * 0.06F;
        float wanderZ = NoiseUtil.perlin2D(noiseTime, 20.0D) * 0.06F;

        double targetY = targetPos.y + target.getBbHeight() * (0.5F + wanderY);
        Vec3 aimVec = new Vec3(targetPos.x + wanderX, targetY, targetPos.z + wanderZ).subtract(player.getEyePosition(1.0F));
        double horizDist = Math.hypot(aimVec.x, aimVec.z);

        float rawYaw = (float) Math.toDegrees(Math.atan2(-aimVec.x, aimVec.z));
        float rawPitch = (float) Mth.clamp(-Math.toDegrees(Math.atan2(aimVec.y, horizDist)), -90.0D, 90.0D);

        float currentYaw = RotationContext.isActive() ? RotationContext.getServerYaw() : player.getYRot();
        float currentPitch = RotationContext.isActive() ? RotationContext.getServerPitch() : player.getXRot();

        float deltaYaw = Mth.wrapDegrees(rawYaw - currentYaw);
        float deltaPitch = rawPitch - currentPitch;
        float totalDist = (float) Math.hypot(deltaYaw, deltaPitch);

        // 3. Dynamic Human Kinematics (Minimum Jerk Trajectory Speed Scaling)
        // Normalized progress ratio based on angular error
        float normalizedDist = Mth.clamp(totalDist / 45.0F, 0.05F, 1.0F);
        // Bell-shaped human acceleration profile: peak velocity around mid-distance, controlled deceleration near target
        double jerkVelocityFactor = 30.0 * Math.pow(normalizedDist, 2) * Math.pow(1.0 - normalizedDist * 0.5, 2);
        float speedScale = (float) Mth.clamp(0.35 + jerkVelocityFactor * 0.12, 0.40, 0.75);

        float maxStepYaw = 35.0F;
        if (totalDist < 5.0F) {
            maxStepYaw = randomLerp(12.0F, 18.0F);
        } else if (totalDist > 25.0F) {
            maxStepYaw = randomLerp(38.0F, 48.0F);
        }

        float stepYaw = Mth.clamp(deltaYaw * speedScale * randomLerp(0.85F, 1.15F), -maxStepYaw, maxStepYaw);

        // Wrist arc trajectory (natural curved path during rotation flicks)
        double arcNoiseTime = now / 180.0D;
        float baseArcStrength = 0.25F + NoiseUtil.perlin1D(arcNoiseTime) * 0.25F;
        float arcJitter = randomLerp(-0.08F, 0.08F) + NoiseUtil.perlin2D(now / 75.0D, 5.0D) * 0.15F;
        float arcMultiplier = baseArcStrength + arcJitter;
        float arcBias = (float) Math.sin(Math.toRadians(deltaYaw)) * (stepYaw * arcMultiplier);

        // Adaptive Pitch tracking: speeds up vertically if target is jumping/falling, stays stable during horizontal tracking
        float pitchSyncRatio = totalDist < 6.0F ? randomLerp(0.35F, 0.55F) : randomLerp(0.20F, 0.35F);
        float maxStepPitch = totalDist < 6.0F ? 15.0F : 25.0F;
        float stepPitch = Mth.clamp(deltaPitch * pitchSyncRatio + arcBias * (0.12F + arcJitter * 0.3F), -maxStepPitch, maxStepPitch);

        // 4. Perlin Noise Tremor with Proximity Damping (avoids cursor shaking off hitbox when on-target)
        double tremorTime = now / 110.0D;
        float proximityDamping = Mth.clamp(totalDist / 4.0F, 0.15F, 1.0F);
        float jitterX = randomLerp(-0.10F, 0.10F);
        float jitterY = randomLerp(-0.06F, 0.06F);
        float tremorYaw = (NoiseUtil.perlin2D(tremorTime, 1.0D) * 0.30F + jitterX) * proximityDamping;
        float tremorPitch = (NoiseUtil.perlin2D(tremorTime, 2.0D) * 0.12F + jitterY) * proximityDamping;

        stepYaw += tremorYaw;
        stepPitch += tremorPitch;

        // 5. Hardware Sensor Simulation (Strict GCD Sensitivity Alignment with Remainder Buffering)
        float gcd = getGCDValue();
        float targetStepYaw = stepYaw + remainderYaw;
        float targetStepPitch = stepPitch + remainderPitch;

        int mX = Math.round(targetStepYaw / gcd);
        int mY = Math.round(targetStepPitch / gcd);

        float finalDeltaYaw = mX * gcd;
        float finalDeltaPitch = mY * gcd;

        remainderYaw = targetStepYaw - finalDeltaYaw;
        remainderPitch = targetStepPitch - finalDeltaPitch;

        RotationContext.setRotation(currentYaw + finalDeltaYaw, Mth.clamp(currentPitch + finalDeltaPitch, -90.0F, 90.0F));
    }

    @Override
    public void reset() {
        targetPositionHistory.clear();
        remainderYaw = 0.0F;
        remainderPitch = 0.0F;
    }

    private static float getGCDValue() {
        float sensitivity = Minecraft.getInstance().options.sensitivity().get().floatValue() * 0.6F + 0.2F;
        return sensitivity * sensitivity * sensitivity * 8.0F * 0.15F;
    }

    private static float randomLerp(float min, float max) {
        return min + ThreadLocalRandom.current().nextFloat() * (max - min);
    }
}
