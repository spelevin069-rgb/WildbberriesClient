package org.blade.utils.combat.rotations.neuro;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.blade.utils.ConfigIO;
import org.blade.utils.math.Angle;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class NeuroAuraSystem {
    private static final long MIN_RECORD_INTERVAL = 50L;
    private static final int MAX_RECORDED_PATTERNS = 4000;

    private final List<NeuroPattern> recordedPatterns = new CopyOnWriteArrayList<>();
    private final List<Vec3> targetPoints = new ArrayList<>();

    private boolean isRecording = false;
    private boolean isUsingNeuro = false;
    private boolean showStats = true;
    private String currentPatternName = "default";
    private String lastDebugMessage = "§7Готов";

    private long lastRecordTime = 0L;
    private int recordedThisSession = 0;
    private long sessionStartTime = 0L;
    private int tickCounter = 0;

    private PerlinNoise noise = new PerlinNoise();
    private long startTime = System.currentTimeMillis();
    private float smoothFactor = 0.25F;
    private float noiseFactor = 1.0F;

    private Vec3 lastTargetPos = null;
    private boolean initialized = false;
    private float lastYaw = 0.0F;
    private float lastPitch = 0.0F;
    private float remainderYaw = 0.0F;
    private float remainderPitch = 0.0F;
    private int currentPointIndex = 0;

    public NeuroAuraSystem() {
        createPatternsDirectory();
        this.startTime = System.currentTimeMillis();
        loadDefaultProfile();
    }

    private Path getPatternsDir() {
        try {
            return ConfigIO.resolve("neuro_patterns");
        } catch (Throwable t) {
            return Path.of("neuro_patterns");
        }
    }

    private void createPatternsDirectory() {
        try {
            Path dir = getPatternsDir();
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadDefaultProfile() {
        Path dir = getPatternsDir();
        Path defaultFile = dir.resolve("default.neuro");
        if (Files.exists(defaultFile)) {
            loadPatterns("default");
        } else {
            generateBaselinePatterns();
            savePatterns("default");
        }
    }

    public void recordTick(LocalPlayer player, LivingEntity target, float currentYaw, float currentPitch) {
        if (!isRecording) return;
        if (player == null || target == null || !target.isAlive()) return;

        tickCounter++;
        if (tickCounter % 2 != 0) return;

        long now = System.currentTimeMillis();
        if (now - lastRecordTime < MIN_RECORD_INTERVAL) return;

        Vec3 eyePos = player.getEyePosition();
        Vec3 targetEye = target.getEyePosition();
        Vec3 delta = targetEye.subtract(eyePos);
        double horizontalDist = Math.sqrt(delta.x * delta.x + delta.z * delta.z);

        float perfectYaw = (float) Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F;
        float perfectPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontalDist));

        float yawDiff = Mth.wrapDegrees(currentYaw - perfectYaw);
        float pitchDiff = currentPitch - perfectPitch;

        double distance = eyePos.distanceTo(targetEye);
        boolean isCritical = player.fallDistance > 0.0F && !player.onGround();
        double targetSpeed = target.getDeltaMovement().horizontalDistance();
        String targetType = (target instanceof Player) ? "player" : "mob";

        SituationKey situationKey = SituationKey.fromEntity(player, target);

        NeuroPattern pattern = new NeuroPattern(
                yawDiff,
                pitchDiff,
                distance,
                isCritical,
                targetSpeed,
                targetType,
                situationKey
        );

        recordedPatterns.add(pattern);
        lastRecordTime = now;
        recordedThisSession++;

        while (recordedPatterns.size() > MAX_RECORDED_PATTERNS) {
            recordedPatterns.remove(0);
        }

        if (recordedThisSession % 20 == 0) {
            lastDebugMessage = "§aЗаписано: §f" + recordedPatterns.size() + " паттернов";
        }
    }

    public void recordAttack(LocalPlayer player, LivingEntity target, float currentYaw, float currentPitch) {
        recordTick(player, target, currentYaw, currentPitch);
    }

    public Angle getNeuroRotation(LocalPlayer player, LivingEntity target, boolean attackLikely) {
        if (target == null || player == null || !target.isAlive()) {
            return null;
        }

        if (recordedPatterns.isEmpty()) {
            generateBaselinePatterns();
        }

        Vec3 eyePos = player.getEyePosition();
        Vec3 targetEye = target.getEyePosition();
        Vec3 delta = targetEye.subtract(eyePos);
        double horizontalDist = Math.max(0.001D, Math.sqrt(delta.x * delta.x + delta.z * delta.z));

        float perfectYaw = (float) Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F;
        float perfectPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontalDist));
        perfectYaw = Mth.wrapDegrees(perfectYaw);
        perfectPitch = Mth.clamp(perfectPitch, -90.0F, 90.0F);

        double currentDistance = eyePos.distanceTo(targetEye);
        double targetSpeed = target.getDeltaMovement().horizontalDistance();

        List<NeuroPattern> similarPatterns = new ArrayList<>();
        for (NeuroPattern p : recordedPatterns) {
            double distDiff = Math.abs(p.getDistance() - currentDistance);
            double speedDiff = Math.abs(p.getTargetSpeed() - targetSpeed);
            if (distDiff < 2.0D && speedDiff < 0.7D) {
                similarPatterns.add(p);
            }
        }

        if (similarPatterns.isEmpty()) {
            int start = Math.max(0, recordedPatterns.size() - 800);
            similarPatterns = recordedPatterns.subList(start, recordedPatterns.size());
        }

        float avgYawDiff = 0.0F;
        float avgPitchDiff = 0.0F;
        float totalWeight = 0.0F;

        for (NeuroPattern p : similarPatterns) {
            float distWeight = 1.0F - (float) Math.min(1.0D, Math.abs(p.getDistance() - currentDistance) / 5.0D);
            float weight = Math.max(0.01F, distWeight);
            avgYawDiff += p.getYaw() * weight;
            avgPitchDiff += p.getPitch() * weight;
            totalWeight += weight;
        }

        if (totalWeight > 0.0F) {
            avgYawDiff /= totalWeight;
            avgPitchDiff /= totalWeight;
        }

        // Clamp learned pattern deltas within safe bounds
        avgYawDiff = Mth.clamp(avgYawDiff, -30.0F, 30.0F);
        avgPitchDiff = Mth.clamp(avgPitchDiff, -20.0F, 20.0F);

        float baseYaw = Mth.wrapDegrees(perfectYaw + avgYawDiff);
        float basePitch = Mth.clamp(perfectPitch + avgPitchDiff, -90.0F, 90.0F);

        if (player.tickCount % 500 == 0) {
            this.noise = new PerlinNoise();
            this.noiseFactor = 1.0F;
        }

        long timeElapsed = System.currentTimeMillis() - startTime;
        float yawNoise = (float) this.noise.noise(timeElapsed * 5.0E-4D);
        float pitchNoise = (float) this.noise.noise(timeElapsed * 5.0E-4D, 10.0D);

        float targetYaw = baseYaw + yawNoise * 2.0F * this.noiseFactor;
        float targetPitch = basePitch + pitchNoise * 1.5F * this.noiseFactor;

        // Initialize angles on target acquisition from current player rotation
        if (!initialized) {
            this.lastYaw = org.blade.context.RotationContext.isActive()
                    ? org.blade.context.RotationContext.getServerYaw()
                    : player.getYRot();
            this.lastPitch = org.blade.context.RotationContext.isActive()
                    ? org.blade.context.RotationContext.getServerPitch()
                    : player.getXRot();
            this.initialized = true;
        }

        float deltaYaw = Mth.wrapDegrees(targetYaw - this.lastYaw);
        float deltaPitch = targetPitch - this.lastPitch;

        float smooth = Mth.clamp(this.smoothFactor, 0.05F, 1.0F);
        float finalYaw = Mth.wrapDegrees(this.lastYaw + deltaYaw * smooth);
        float finalPitch = this.lastPitch + deltaPitch * smooth;

        if (lastTargetPos == null || !lastTargetPos.equals(target.position())) {
            updateTargetPoints(target);
            lastTargetPos = target.position();
        }

        if (!targetPoints.isEmpty()) {
            currentPointIndex = (currentPointIndex + 1) % targetPoints.size();
            Vec3 targetPoint = targetPoints.get(currentPointIndex);
            Vec3 ptVec = targetPoint.subtract(eyePos);
            double ptH = Math.max(0.1D, Math.sqrt(ptVec.x * ptVec.x + ptVec.z * ptVec.z));
            float ptYaw = (float) Math.toDegrees(Math.atan2(ptVec.z, ptVec.x)) - 90.0F;
            float ptPitch = (float) -Math.toDegrees(Math.atan2(ptVec.y, ptH));

            float mixFactor = 0.01F;
            finalYaw = finalYaw * (1.0F - mixFactor) + ptYaw * mixFactor;
            finalPitch = finalPitch * (1.0F - mixFactor) + ptPitch * mixFactor;
        }

        // Strictly bound final pitch within the target's physical hitbox
        AABB box = target.getBoundingBox();
        double distH = Math.max(0.1D, Math.sqrt(delta.x * delta.x + delta.z * delta.z));
        float minBoxPitch = (float) -Math.toDegrees(Math.atan2(box.maxY - eyePos.y + 0.1D, distH));
        float maxBoxPitch = (float) -Math.toDegrees(Math.atan2(box.minY - eyePos.y - 0.1D, distH));
        float topPitch = Math.min(minBoxPitch, maxBoxPitch);
        float bottomPitch = Math.max(minBoxPitch, maxBoxPitch);

        finalPitch = Mth.clamp(finalPitch, topPitch, bottomPitch);
        finalPitch = Mth.clamp(finalPitch, -90.0F, 90.0F);
        finalYaw = Mth.wrapDegrees(finalYaw);

        float gcd = getGCDValue();
        float stepYaw = Mth.wrapDegrees(finalYaw - this.lastYaw) + remainderYaw;
        float stepPitch = (finalPitch - this.lastPitch) + remainderPitch;

        int mX = Math.round(stepYaw / gcd);
        int mY = Math.round(stepPitch / gcd);

        float finalDeltaYaw = mX * gcd;
        float finalDeltaPitch = mY * gcd;

        remainderYaw = stepYaw - finalDeltaYaw;
        remainderPitch = stepPitch - finalDeltaPitch;

        finalYaw = Mth.wrapDegrees(this.lastYaw + finalDeltaYaw);
        finalPitch = Mth.clamp(this.lastPitch + finalDeltaPitch, -90.0F, 90.0F);

        this.lastYaw = finalYaw;
        this.lastPitch = finalPitch;

        lastDebugMessage = String.format("§aНейро: Y%.1f° P%.1f° | Шум: %.2f", avgYawDiff, avgPitchDiff, this.noiseFactor);
        return new Angle(finalYaw, finalPitch);
    }

    private void updateTargetPoints(LivingEntity target) {
        targetPoints.clear();
        AABB box = target.getBoundingBox();
        Vec3 center = target.getEyePosition();
        targetPoints.add(center);
        targetPoints.add(new Vec3(center.x, box.minY + 0.1D, center.z));
        targetPoints.add(new Vec3(center.x, box.maxY - 0.1D, center.z));
        targetPoints.add(new Vec3(box.minX + 0.2D, center.y, center.z));
        targetPoints.add(new Vec3(box.maxX - 0.2D, center.y, center.z));
        targetPoints.add(new Vec3(center.x, center.y, box.minZ + 0.2D));
        targetPoints.add(new Vec3(center.x, center.y, box.maxZ - 0.2D));

        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < 3; i++) {
            double x = random.nextDouble(box.minX, box.maxX);
            double y = random.nextDouble(box.minY, box.maxY);
            double z = random.nextDouble(box.minZ, box.maxZ);
            targetPoints.add(new Vec3(x, y, z));
        }
        Collections.shuffle(targetPoints);
    }

    /**
     * Optimizes and trains the pattern database:
     * 1. Filters unnatural aim spikes / desync outliers.
     * 2. Groups into SituationKey clusters.
     * 3. Performs data augmentation for sparse combat situations.
     */
    public String trainModel() {
        if (recordedPatterns.isEmpty()) {
            generateBaselinePatterns();
            return "§eСгенерирована базовая модель: " + recordedPatterns.size() + " паттернов";
        }

        int initialCount = recordedPatterns.size();
        List<NeuroPattern> valid = new ArrayList<>();
        int removedOutliers = 0;

        for (NeuroPattern p : recordedPatterns) {
            if (Math.abs(p.getYaw()) > 45.0F || Math.abs(p.getPitch()) > 35.0F) {
                removedOutliers++;
                continue;
            }
            valid.add(p);
        }

        Map<String, List<NeuroPattern>> situationClusters = new HashMap<>();
        for (NeuroPattern p : valid) {
            String key = p.getSituationKey() != null ? p.getSituationKey().toString() : "generic";
            situationClusters.computeIfAbsent(key, k -> new ArrayList<>()).add(p);
        }

        // Augment situations with low representation
        ThreadLocalRandom rand = ThreadLocalRandom.current();
        List<NeuroPattern> augmented = new ArrayList<>(valid);
        for (Map.Entry<String, List<NeuroPattern>> entry : situationClusters.entrySet()) {
            List<NeuroPattern> cluster = entry.getValue();
            if (cluster.size() < 10) {
                for (NeuroPattern base : cluster) {
                    for (int i = 0; i < 3; i++) {
                        float yawJitter = (float) rand.nextGaussian() * 0.4F;
                        float pitchJitter = (float) rand.nextGaussian() * 0.3F;
                        augmented.add(new NeuroPattern(
                                base.getYaw() + yawJitter,
                                base.getPitch() + pitchJitter,
                                base.getDistance(),
                                base.isCritical(),
                                base.getTargetSpeed(),
                                base.getTargetType(),
                                base.getSituationKey()
                        ));
                    }
                }
            }
        }

        recordedPatterns.clear();
        recordedPatterns.addAll(augmented);

        if (currentPatternName != null && !currentPatternName.isEmpty()) {
            savePatterns(currentPatternName);
        }

        return String.format("§aОбучение завершено: %d -> %d паттернов (%d кластеров, %d выбросов удалено)",
                initialCount, recordedPatterns.size(), situationClusters.size(), removedOutliers);
    }

    /**
     * Synthesizes realistic human-aim baseline patterns across all combat situations.
     */
    public void generateBaselinePatterns() {
        recordedPatterns.clear();
        ThreadLocalRandom rand = ThreadLocalRandom.current();
        String[] types = {"player", "mob"};
        String[] distances = {"close", "medium", "far"};
        String[] movements = {"stationary", "walking", "sprinting", "jumping"};
        String[] crits = {"crit", "nocrit"};
        String[] healths = {"high", "medium", "low"};

        for (String type : types) {
            for (String distBucket : distances) {
                double dist = distBucket.equals("close") ? 2.0D : (distBucket.equals("medium") ? 3.2D : 4.5D);
                for (String move : movements) {
                    double speed = move.equals("stationary") ? 0.0D : (move.equals("walking") ? 0.15D : (move.equals("sprinting") ? 0.28D : 0.22D));
                    for (String crit : crits) {
                        boolean isCrit = crit.equals("crit");
                        SituationKey key = new SituationKey(type, distBucket, move, crit, "high");

                        for (int i = 0; i < 4; i++) {
                            float yawNoise = (float) rand.nextGaussian() * (move.equals("sprinting") ? 1.4F : 0.8F);
                            float pitchNoise = (float) rand.nextGaussian() * 0.7F;
                            if (isCrit) pitchNoise -= 0.5F;

                            recordedPatterns.add(new NeuroPattern(
                                    yawNoise,
                                    pitchNoise,
                                    dist + rand.nextDouble(-0.3D, 0.3D),
                                    isCrit,
                                    speed,
                                    type,
                                    key
                            ));
                        }
                    }
                }
            }
        }
        lastDebugMessage = "§aСгенерировано: " + recordedPatterns.size() + " базовых паттернов";
    }

    public void savePatterns(String profileName) {
        if (recordedPatterns.isEmpty()) {
            lastDebugMessage = "§cНет паттернов";
            return;
        }

        try {
            createPatternsDirectory();
            Path file = getPatternsDir().resolve(profileName + ".neuro");
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file.toFile()))) {
                oos.writeObject(new ArrayList<>(recordedPatterns));
            }
            this.currentPatternName = profileName;
            this.lastDebugMessage = "§aСохранено " + recordedPatterns.size() + " паттернов в " + profileName;
        } catch (IOException e) {
            this.lastDebugMessage = "§cОшибка сохранения: " + e.getMessage();
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public void loadPatterns(String profileName) {
        try {
            Path file = getPatternsDir().resolve(profileName + ".neuro");
            if (!Files.exists(file)) {
                this.lastDebugMessage = "§eНет сохранений: " + profileName;
                return;
            }

            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file.toFile()))) {
                List<NeuroPattern> loaded = (List<NeuroPattern>) ois.readObject();
                recordedPatterns.clear();
                recordedPatterns.addAll(loaded);
                this.currentPatternName = profileName;
                this.lastDebugMessage = "§aЗагружено " + recordedPatterns.size() + " паттернов из " + profileName;
            }
        } catch (IOException | ClassNotFoundException e) {
            this.lastDebugMessage = "§cОшибка загрузки: " + e.getMessage();
            e.printStackTrace();
        }
    }

    public List<String> getPatternNames() {
        List<String> patterns = new ArrayList<>();
        File dir = getPatternsDir().toFile();
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles((d, name) -> name.endsWith(".neuro"));
            if (files != null) {
                for (File file : files) {
                    String name = file.getName();
                    patterns.add(name.substring(0, name.length() - 6));
                }
            }
        }
        return patterns;
    }

    public void clearPatterns() {
        recordedPatterns.clear();
        recordedThisSession = 0;
        currentPatternName = null;
        lastDebugMessage = "§eПаттерны очищены";
    }

    public void startRecording() {
        isRecording = true;
        recordedThisSession = 0;
        sessionStartTime = System.currentTimeMillis();
        lastDebugMessage = "§aЗапись начата";
    }

    public void stopRecording() {
        isRecording = false;
        lastDebugMessage = "§eЗапись остановлена";
    }

    public void reset() {
        this.initialized = false;
        this.lastYaw = 0.0F;
        this.lastPitch = 0.0F;
        this.remainderYaw = 0.0F;
        this.remainderPitch = 0.0F;
        this.lastTargetPos = null;
        this.targetPoints.clear();
    }

    private static float getGCDValue() {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.options == null) return 0.15F;
        float sensitivity = mc.options.sensitivity().get().floatValue() * 0.6F + 0.2F;
        return sensitivity * sensitivity * sensitivity * 1.2F;
    }

    public String getStatusString() {
        StringBuilder sb = new StringBuilder("§8[§bNeuro§8] §fПаттернов: §e").append(recordedPatterns.size());
        if (isRecording) {
            sb.append(" §a[ЗАПИСЬ");
            if (recordedThisSession > 0) {
                sb.append(" +").append(recordedThisSession);
            }
            sb.append("]");
        }
        if (isUsingNeuro) {
            sb.append(" §b[АКТИВЕН");
            if (currentPatternName != null) {
                sb.append(" §7(").append(currentPatternName).append(")");
            }
            sb.append("]");
        }
        return sb.toString();
    }

    public int getPatternCount() {
        return recordedPatterns.size();
    }

    public List<NeuroPattern> getRecordedPatterns() {
        return recordedPatterns;
    }

    public boolean isRecording() {
        return isRecording;
    }

    public void setRecording(boolean recording) {
        this.isRecording = recording;
    }

    public boolean isUsingNeuro() {
        return isUsingNeuro;
    }

    public void setUsingNeuro(boolean usingNeuro) {
        this.isUsingNeuro = usingNeuro;
    }

    public boolean isShowStats() {
        return showStats;
    }

    public void setShowStats(boolean showStats) {
        this.showStats = showStats;
    }

    public String getCurrentPatternName() {
        return currentPatternName;
    }

    public void setCurrentPatternName(String currentPatternName) {
        this.currentPatternName = currentPatternName;
    }

    public String getLastDebugMessage() {
        return lastDebugMessage;
    }

    public int getRecordedThisSession() {
        return recordedThisSession;
    }

    public float getSmoothFactor() {
        return smoothFactor;
    }

    public void setSmoothFactor(float smoothFactor) {
        this.smoothFactor = smoothFactor;
    }

    public float getNoiseFactor() {
        return noiseFactor;
    }

    public void setNoiseFactor(float noiseFactor) {
        this.noiseFactor = noiseFactor;
    }
}
