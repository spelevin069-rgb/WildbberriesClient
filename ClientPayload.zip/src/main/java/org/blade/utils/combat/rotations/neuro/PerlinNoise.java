package org.blade.utils.combat.rotations.neuro;

import org.blade.utils.math.NoiseUtil;

import java.util.concurrent.ThreadLocalRandom;

public class PerlinNoise {
    private final double offsetX;
    private final double offsetY;

    public PerlinNoise() {
        this.offsetX = ThreadLocalRandom.current().nextDouble(0.0D, 10000.0D);
        this.offsetY = ThreadLocalRandom.current().nextDouble(0.0D, 10000.0D);
    }

    public double noise(double x) {
        return NoiseUtil.perlin2D(x + offsetX, offsetY);
    }

    public double noise(double x, double y) {
        return NoiseUtil.perlin2D(x + offsetX, y + offsetY);
    }
}
