package org.blade.utils.render;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.blade.utils.math.MathUtil;
import org.blade.utils.ColorUtil;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class Theme {
    private static int accentIndex;

    public static int getAccent() {
        return Colors.ACCENTS[accentIndex];
    }

    public static int accent(int index) {
        return Colors.ACCENTS[MathUtil.clamp(index, 0, Colors.ACCENTS.length - 1)];
    }

    public static int accentCount() {
        return Colors.ACCENTS.length;
    }

    public static void setAccentIndex(int index) {
        accentIndex = MathUtil.clamp(index, 0, Colors.ACCENTS.length - 1);
    }

    public static int accentIndex() {
        return accentIndex;
    }

    public static void saveAccentPreset(int index, int color) {
        Colors.ACCENTS[MathUtil.clamp(index, 0, Colors.ACCENTS.length - 1)] = ColorUtil.withAlpha(color, 255);
        accentIndex = MathUtil.clamp(index, 0, Colors.ACCENTS.length - 1);
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static final class Colors {
        public static final int PANEL = ColorUtil.rgb(8, 9, 12);
        public static final int BACKGROUND_PRIMARY_50 = ColorUtil.rgba(8, 9, 12, 238);
        public static final int PANEL_BORDER = ColorUtil.rgba(255, 255, 255, 20);
        public static final int PANEL_SHADOW = ColorUtil.rgba(0, 0, 0, 38);
        public static final int PANEL_SHADOW_STRONG = ColorUtil.rgba(0, 0, 0, 89);
        public static final int POPUP_SHADOW = ColorUtil.rgba(0, 0, 0, 102);
        public static final int OVERLAY = ColorUtil.rgb(6, 7, 10);

        public static final int CARD = ColorUtil.rgb(15, 17, 22);
        public static final int CARD_HOVER = ColorUtil.rgb(23, 25, 31);
        public static final int MODULE_CARD = ColorUtil.rgb(13, 15, 19);
        public static final int MODULE_CARD_HOVER = ColorUtil.rgb(21, 23, 28);
        public static final int BACKGROUND_SURFACE_S = ColorUtil.rgb(15, 17, 22);
        public static final int BACKGROUND_SURFACE_M = ColorUtil.rgb(28, 30, 36);
        public static final int CONTROL = ColorUtil.rgb(29, 31, 37);
        public static final int CONTROL_ALT = ColorUtil.rgb(29, 31, 37);
        public static final int CONTROL_STRONG = ColorUtil.rgb(37, 39, 46);
        public static final int CONTROL_HOVER = ColorUtil.rgb(46, 48, 56);
        public static final int CONTROL_IDLE = ColorUtil.rgb(32, 34, 40);
        public static final int OUTLINES_SMALL = ColorUtil.rgba(255, 255, 255, 8);
        public static final int OUTLINES_MEDIUM = ColorUtil.rgba(255, 255, 255, 13);
        public static final int OUTLINES_LARGE = ColorUtil.rgba(255, 255, 255, 20);
        public static final int SYSTEM_INFORMATION = ColorUtil.rgb(0, 145, 255);
        public static final int SYSTEM_RED = ColorUtil.rgb(237, 106, 95);
        public static final int CONTROL_SHADOW = ColorUtil.rgba(0, 0, 0, 26);
        public static final int TEXT_TITLE = ColorUtil.WHITE;
        public static final int TEXT_TEXT = ColorUtil.rgb(217, 213, 201);
        public static final int TEXT = ColorUtil.rgb(236, 232, 222);
        public static final int PRIMARY = ColorUtil.rgb(247, 244, 236);
        public static final int PRIMARY_BRIGHT = ColorUtil.rgb(255, 250, 243);
        public static final int SECONDARY = ColorUtil.rgb(168, 165, 159);
        public static final int SECONDARY_DARK = ColorUtil.rgb(137, 138, 133);
        public static final int SECTION = ColorUtil.rgb(132, 129, 126);
        public static final int DIVIDER = ColorUtil.rgba(255, 255, 255, 18);
        public static final int DIVIDER_SUBTLE = ColorUtil.rgba(255, 255, 255, 15);
        public static final int DIVIDER_HEADER = ColorUtil.rgba(255, 255, 255, 8);
        public static final int SEPARATOR = ColorUtil.rgba(255, 255, 255, 20);
        public static final int SURFACE_ACTIVE = ColorUtil.rgba(255, 255, 255, 24);
        public static final int SURFACE_HOVER = ColorUtil.rgba(255, 255, 255, 12);
        public static final int FOCUS = ColorUtil.rgba(255, 255, 255, 128);
        public static final int ICON = ColorUtil.rgb(153, 151, 148);
        public static final int ICON_MUTED = ColorUtil.rgb(186, 181, 178);
        public static final int ICON_GHOST = ColorUtil.rgb(84, 82, 82);
        public static final int TEXT_GHOST = ICON_GHOST;
        public static final int TRAFFIC_CLOSE = ColorUtil.rgb(237, 106, 95);
        public static final int TRAFFIC_MINIMIZE = ColorUtil.rgb(245, 191, 79);
        public static final int TRAFFIC_MAXIMIZE = ColorUtil.rgb(97, 197, 84);
        public static final int RISK = TRAFFIC_MINIMIZE;
        public static final int EXTRA_RISK = TRAFFIC_CLOSE;
        public static final int DOCK = ColorUtil.rgba(16, 18, 23, 242);
        public static final int DOCK_BORDER = ColorUtil.rgba(255, 255, 255, 36);
        public static final int DOCK_SHADOW = ColorUtil.rgba(0, 0, 0, 56);
        public static final int[] ACCENTS = {
                ColorUtil.rgb(238, 240, 245), ColorUtil.rgb(170, 175, 185), ColorUtil.rgb(112, 118, 130),
                ColorUtil.rgb(213, 68, 199), ColorUtil.rgb(242, 77, 114), ColorUtil.rgb(255, 108, 87),
                ColorUtil.rgb(255, 141, 80), ColorUtil.rgb(255, 189, 80), ColorUtil.rgb(255, 219, 101),
                ColorUtil.rgb(143, 208, 93)
        };
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static final class Sizes {
        public static final int HEADER_HEIGHT = 56;
        public static final int DEFAULT_PANEL_RADIUS_INDEX = 1;
        public static final int[] PANEL_RADII = {6, 12, 20};
        public static final int MODULE_CARD_RADIUS = 8;
        public static final int MODULE_CARD_HEADER_HEIGHT = 64;
        public static final int MODULE_CARD_ROW_HEIGHT = 34;
        public static final int MODULE_CARD_PADDING = 16;
        public static final int MODULE_CARD_SWITCH_WIDTH = 36;
        public static final int MODULE_CARD_SWITCH_HEIGHT = 16;
        public static final int MODULE_CARD_ACTION_ICON = 12;
        public static final int SLIDER_WIDTH = 128;
        public static final int SLIDER_HEIGHT = 14;
        public static final int SLIDER_PADDING = 2;
        public static final int SLIDER_TRACK_HEIGHT = 3;
        public static final int SLIDER_KNOB_SIZE = 10;
        public static final float SLIDER_SHADOW_BLUR = 7.5F;
        public static final int MODULE_CARD_SLIDER_WIDTH = SLIDER_WIDTH;
        public static final int MODULE_CARD_SLIDER_HEIGHT = SLIDER_HEIGHT;
        public static final int COLOR_PREVIEW_WIDTH = 24;
        public static final int COLOR_PREVIEW_HEIGHT = 16;
        public static final int COLOR_PREVIEW_PADDING = 2;
        public static final int COLOR_PREVIEW_RADIUS = 6;
        public static final int COLOR_BLOCK_RADIUS = 4;
        public static final int COLOR_PICKER_WIDTH = 144;
        public static final int COLOR_PICKER_HEIGHT = 122;
        public static final int COLOR_PICKER_PADDING = 6;
        public static final int COLOR_PICKER_RADIUS = 12;
        public static final int COLOR_PICKER_GRID_WIDTH = 132;
        public static final int COLOR_PICKER_GRID_HEIGHT = 110;
        public static final int COLOR_PICKER_GRID_RADIUS = 10;
        public static final int COLOR_PICKER_CELL_SIZE = 11;
        public static final int COLOR_PICKER_COLUMNS = 12;
        public static final int COLOR_PICKER_OFFSET_Y = 4;
        public static final int DROPDOWN_VALUE_WIDTH = 112;
        public static final int DROPDOWN_VALUE_HEIGHT = 24;
        public static final int DROPDOWN_GAP = 4;
        public static final int DROPDOWN_ICON_SIZE = 24;
        public static final int DROPDOWN_ICON_PADDING = 4;
        public static final int DROPDOWN_POPUP_WIDTH = 144;
        public static final int DROPDOWN_POPUP_RADIUS = 12;
        public static final int DROPDOWN_POPUP_PADDING = 6;
        public static final int DROPDOWN_POPUP_GAP = 2;
        public static final int DROPDOWN_POPUP_ITEM_HEIGHT = 32;
        public static final int DROPDOWN_POPUP_ITEM_RADIUS = 8;
        public static final int DROPDOWN_POPUP_TEXT_WIDTH = 108;
        public static final int DROPDOWN_POPUP_OFFSET_Y = 4;
        public static final int INPUT_BIND_WIDTH = 44;
        public static final int INPUT_BIND_HEIGHT = 20;
        public static final int INPUT_BIND_RADIUS = 4;
        public static final int INPUT_BIND_PADDING_X = 8;
        public static final int INPUT_BIND_TEXT_SIZE = 10;
        public static final int INPUT_WIDTH = 128;
        public static final int INPUT_HEIGHT = 24;
        public static final int INPUT_RADIUS = 4;
        public static final int INPUT_PADDING_X = 8;
        public static final int INPUT_PADDING_Y = 4;
        public static final int INPUT_TEXT_WIDTH = 112;
        public static final int INPUT_TEXT_SIZE = 10;
        public static final float HEADER_BRAND_WIDTH = 330.6666564941406F;
        public static final int HEADER_BRAND_HEIGHT = 32;
        public static final int HEADER_BRAND_RADIUS = 8;
        public static final int HEADER_CONTROLS_X = 16;
        public static final int HEADER_CONTROLS_Y = 12;
        public static final int HEADER_CONTROLS_HEIGHT = 32;
        public static final int HEADER_CONTROLS_GAP = 8;
        public static final int HEADER_TRAFFIC_SIZE = 12;
        public static final int HEADER_TRAFFIC_GAP = 10;
        public static final int HEADER_CONTROL_BUTTON_SIZE = 24;
        public static final int HEADER_CONTROL_BUTTON_PADDING = 4;
        public static final int HEADER_NAV_GROUP_WIDTH = 48;
        public static final int HEADER_ICON_SIZE = 16;
        public static final int HEADER_PROFILE_ICON_SIZE = 20;
        public static final int HEADER_DIVIDER_HEIGHT = 12;
    }
}
