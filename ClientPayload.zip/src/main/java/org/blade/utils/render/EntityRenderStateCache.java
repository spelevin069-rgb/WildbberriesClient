package org.blade.utils.render;

import net.minecraft.client.renderer.entity.state.EntityRenderState;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class EntityRenderStateCache {
    private static volatile List<EntityRenderState> frameStates = Collections.emptyList();

    private EntityRenderStateCache() {
    }

    public static void capture(List<EntityRenderState> states) {
        frameStates = states == null || states.isEmpty()
                ? Collections.emptyList()
                : new ArrayList<>(states);
    }

    public static List<EntityRenderState> currentStates() {
        return frameStates;
    }

    public static void clear() {
        frameStates = Collections.emptyList();
    }
}
