package org.blade.utils.render.world;

import org.blade.feature.impl.combat.AuraFeature;
import org.blade.feature.impl.player.FullBrightFeature;
import org.blade.feature.impl.visual.ChamsFeature;
import org.blade.feature.impl.visual.PopChamsFeature;
import org.blade.feature.impl.visual.TrajectoriesFeature;
import org.blade.feature.impl.visual.WorldParticlesFeature;
import org.blade.feature.impl.visual.WorldTweaksFeature;
import org.blade.utils.render.chams.ChamsPipeline;
import org.blade.utils.render.chams.PopChamsRenderer;
import org.blade.utils.render.target.TargetMarkers;

import java.util.ArrayList;
import java.util.List;

public final class WorldEffects {
    private static final List<WorldEffect> EFFECTS = new ArrayList<>();

    private WorldEffects() {
    }

    public static void bootstrap() {
        if (!EFFECTS.isEmpty()) {
            return;
        }

        register(WorldEffect.lazy(
                () -> gate(WorldTweaksFeature.getEnabled(), WorldTweaksFeature::usesSky),
                WorldTweaksRenderer::new,
                (feature, renderer, context) -> renderer.renderSky(feature, context.cameraRenderState()),
                WorldTweaksRenderer::release
        ));

        register(WorldEffect.lazy(
                () -> gate(FullBrightFeature.getEnabled(), FullBrightFeature::usesShaderLights),
                DynamicLightRenderer::new,
                (feature, renderer, context) -> renderer.render(feature, context.cameraRenderState(), context.tickDelta()),
                DynamicLightRenderer::release
        ));

        register(WorldEffect.lazy(
                ChamsFeature::getEnabled,
                ChamsPipeline::new,
                (feature, pipeline, context) -> pipeline.render(context.levelRenderState(), feature),
                ChamsPipeline::release
        ));

        register(WorldEffect.direct(
                TrajectoriesFeature::getEnabled,
                (feature, context) -> feature.renderWorld()
        ));

        register(WorldEffect.direct(
                WorldParticlesFeature::getEnabled,
                (feature, context) -> feature.renderWorld(context.levelRenderState().cameraRenderState, context.tickDelta())
        ));

        register(WorldEffect.lazy(
                PopChamsFeature::getEnabled,
                PopChamsRenderer::new,
                (feature, renderer, context) -> renderer.render(context.levelRenderState(), feature),
                PopChamsRenderer::release
        ));

        register(WorldEffect.lazy(
                AuraFeature::getMarkerFeature,
                TargetMarkers::new,
                (feature, markers, context) -> markers.render(feature, context.tickDelta()),
                TargetMarkers::release
        ));

        register(WorldEffect.lazy(
                () -> gate(WorldTweaksFeature.getEnabled(), WorldTweaksFeature::usesSaturation),
                WorldTweaksRenderer::new,
                (feature, renderer, context) -> renderer.renderSaturation(feature),
                WorldTweaksRenderer::release
        ));
    }

    public static void register(WorldEffect effect) {
        EFFECTS.add(effect);
    }

    public static void render(WorldEffectContext context) {
        for (WorldEffect effect : EFFECTS) {
            if (effect.active()) {
                effect.render(context);
            } else {
                effect.release();
            }
        }
    }

    private static <F> F gate(F feature, java.util.function.Predicate<F> enabled) {
        return feature != null && enabled.test(feature) ? feature : null;
    }
}
