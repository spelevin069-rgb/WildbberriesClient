package org.blade.utils.math;

public record Angle(float yaw, float pitch) {
}
