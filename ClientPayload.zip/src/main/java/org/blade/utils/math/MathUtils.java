package org.blade.utils.math;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class MathUtils {

    private MathUtils() {
    }

    public static Angle getRotation(Vec3 from, Vec3 to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;

        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(-Math.atan2(dy, horizontal));

        return new Angle(yaw, pitch);
    }

    public static double getFov(Vec3 to) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            return 180.0D;
        }
        return getFov(player, to);
    }

    public static double getFov(LocalPlayer player, Vec3 to) {
        if (player == null) {
            return 180.0D;
        }
        Angle angle = getRotation(player.getEyePosition(), to);
        return Math.abs(Mth.wrapDegrees(angle.yaw() - player.getYRot()));
    }
}
