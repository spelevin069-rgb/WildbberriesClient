package org.blade.utils.math;

import net.minecraft.client.Minecraft;

public final class RotationUtils {

    private RotationUtils() {
    }

    public static float getGCD() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options == null) {
            return 0.15f;
        }
        double sensitivity = mc.options.sensitivity().get();
        double f = sensitivity * 0.6D + 0.2D;
        return (float) (f * f * f * 1.2D);
    }

    public static float applyGCD(float angle, float previous) {
        float gcd = getGCD();
        if (gcd <= 0.0f) {
            return angle;
        }
        float diff = angle - previous;
        float step = Math.round(diff / gcd) * gcd;
        if (step == 0.0f && Math.abs(diff) > 1.0E-4f) {
            step = Math.signum(diff) * gcd;
        }
        return previous + step;
    }

    public static float quantizeStep(float step, float gcd) {
        if (gcd <= 0.0f) return step;
        int m = Math.round(step / gcd);
        return m * gcd;
    }
}
