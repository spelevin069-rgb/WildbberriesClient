package org.blade.feature.impl.combat;

import lombok.Getter;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ambient.AmbientCreature;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Phantom;
import net.minecraft.world.entity.monster.Shulker;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import org.blade.context.MinecraftContext;
import org.blade.event.EventTarget;
import org.blade.event.events.game.AttackEvent;
import org.blade.event.events.game.PlayerTickEvent;
import org.blade.event.events.input.MouseLookEvent;
import org.blade.feature.Feature;
import org.blade.feature.FeatureCategory;
import org.blade.feature.FeatureManager;
import org.blade.feature.impl.movement.InventoryMoveFeature;
import org.blade.feature.setting.BindSetting;
import org.blade.feature.setting.BooleanSetting;
import org.blade.feature.setting.ModeSetting;
import org.blade.feature.setting.MultiSelectSetting;
import org.blade.feature.setting.NumberSetting;
import org.blade.utils.FriendManager;
import org.blade.utils.combat.SprintManager;
import org.blade.utils.math.Angle;
import org.blade.utils.math.MathUtils;
import org.blade.utils.math.RotationUtils;

import java.util.Comparator;
import java.util.List;

public final class AimAssistFeature extends Feature implements MinecraftContext {

    public final ModeSetting mode = register(new ModeSetting(
            "Mode", "Smooth", "Smooth", "Assist Only"
    ));

    public final NumberSetting speed = register(new NumberSetting(
            "Speed", 3.0D, 0.5D, 15.0D, 0.5D, ""
    ));

    public final NumberSetting smoothness = register(new NumberSetting(
            "Smooth", 4.0D, 1.0D, 20.0D, 0.5D, ""
    ));

    public final NumberSetting range = register(new NumberSetting(
            "Range", 4.5D, 2.0D, 8.0D, 0.1D, " blocks"
    ));

    public final NumberSetting fov = register(new NumberSetting(
            "FOV", 90.0D, 10.0D, 180.0D, 5.0D, "°"
    ));

    public final MultiSelectSetting targets = register(new MultiSelectSetting(
            "Targets",
            List.of("Players", "Mobs", "Animals"),
            "Players", "Friends", "Mobs", "Animals"
    ));

    public final MultiSelectSetting checks = register(new MultiSelectSetting(
            "Checks",
            List.of("Visible only"),
            "Weapon only", "Visible only", "Don't eat"
    ));

    public final BooleanSetting pitch = register(new BooleanSetting(
            "Pitch Assist", true
    ));

    public final BooleanSetting clickOnly = register(new BooleanSetting(
            "On Click Only", false
    ));

    public final BooleanSetting sprintReset = register(new BooleanSetting(
            "Sprint Reset", true
    ));

    public final ModeSetting sprintResetMode = register(new ModeSetting(
            "Reset Mode", "W-Tap", "W-Tap", "S-Tap", "Packet"
    ));

    public final BooleanSetting resetOnlyWhenAimed = register(new BooleanSetting(
            "Only When Aimed", true
    ));

    public final BooleanSetting inGui = register(new BooleanSetting(
            "In GUI", false
    ));

    @Getter
    private LivingEntity target;

    public AimAssistFeature() {
        super("AimAssist", "Smoothly pulls crosshair towards targets", FeatureCategory.COMBAT, BindSetting.UNBOUND);
    }

    public static AimAssistFeature getEnabled() {
        return FeatureManager.INSTANCE.getEnabled(AimAssistFeature.class);
    }

    @Override
    protected void onDisable() {
        this.target = null;
    }

    public boolean shouldContinuousAim() {
        if (!isEnabled() || !inGame()) {
            return false;
        }
        if (screen() != null && (!inGui.getValue() || InventoryMoveFeature.getEnabled() == null)) {
            return false;
        }
        if (!mode.is("Smooth")) {
            return false;
        }
        if (clickOnly.getValue() && !mc.mouseHandler.isLeftPressed()) {
            return false;
        }
        LocalPlayer player = mc.player;
        if (player == null) {
            return false;
        }
        if (checks.isSelected("Don't eat") && player.isUsingItem()) {
            return false;
        }
        if (checks.isSelected("Weapon only") && !isHoldingWeapon(player)) {
            return false;
        }
        updateTarget();
        return this.target != null;
    }

    @EventTarget
    public void onPlayerTick(PlayerTickEvent event) {
        if (!event.isPre()) {
            return;
        }
        updateTarget();
    }

    @EventTarget
    public void onMouseLook(MouseLookEvent event) {
        if (!inGame()) {
            return;
        }
        if (screen() != null && (!inGui.getValue() || InventoryMoveFeature.getEnabled() == null)) {
            return;
        }

        LocalPlayer player = mc.player;
        if (player == null) {
            return;
        }

        if (clickOnly.getValue() && !mc.mouseHandler.isLeftPressed()) {
            return;
        }

        if (checks.isSelected("Don't eat") && player.isUsingItem()) {
            return;
        }

        if (checks.isSelected("Weapon only") && !isHoldingWeapon(player)) {
            return;
        }

        updateTarget();

        LivingEntity currentTarget = this.target;
        if (currentTarget == null) {
            return;
        }

        Angle angle = MathUtils.getRotation(player.getEyePosition(), currentTarget.getBoundingBox().getCenter());
        float yawDiff = Mth.wrapDegrees(angle.yaw() - player.getYRot());
        float pitchDiff = angle.pitch() - player.getXRot();

        float spd = speed.getValue().floatValue();
        float smth = Math.max(1.0f, smoothness.getValue().floatValue());

        float pullYaw = (yawDiff / smth) * (spd / 3.0f);
        float pullPitch = (pitchDiff / smth) * (spd / 3.0f);

        float maxStep = spd * 1.5f;
        pullYaw = Mth.clamp(pullYaw, -maxStep, maxStep);
        pullPitch = Mth.clamp(pullPitch, -maxStep, maxStep);

        float pullDeltaX = pullYaw / 0.15f;
        float pullDeltaY = pullPitch / 0.15f;

        float deltaX = (float) event.getDeltaX();
        float finalDeltaX;

        if (Math.abs(deltaX) > 1.0E-4f) {
            boolean movingToTarget = deltaX * yawDiff > 0.0f;
            if (movingToTarget) {
                float boost = pullDeltaX * 0.8f;
                finalDeltaX = RotationUtils.applyGCD(deltaX + boost, deltaX);
            } else {
                finalDeltaX = RotationUtils.applyGCD(deltaX * 0.6f, deltaX);
            }
        } else {
            if (mode.is("Smooth") && Math.abs(yawDiff) > 0.1f) {
                finalDeltaX = RotationUtils.applyGCD(pullDeltaX, 0.0f);
            } else {
                finalDeltaX = deltaX;
            }
        }
        event.setDeltaX(finalDeltaX);

        if (pitch.getValue()) {
            float deltaY = (float) event.getDeltaY();
            float finalDeltaY;

            if (Math.abs(deltaY) > 1.0E-4f) {
                boolean movingToPitch = deltaY * pitchDiff > 0.0f;
                if (movingToPitch) {
                    float boostY = pullDeltaY * 0.8f;
                    finalDeltaY = RotationUtils.applyGCD(deltaY + boostY, deltaY);
                } else {
                    finalDeltaY = RotationUtils.applyGCD(deltaY * 0.6f, deltaY);
                }
            } else {
                if (mode.is("Smooth") && Math.abs(pitchDiff) > 0.1f) {
                    finalDeltaY = RotationUtils.applyGCD(pullDeltaY, 0.0f);
                } else {
                    finalDeltaY = deltaY;
                }
            }
            event.setDeltaY(finalDeltaY);
        }
    }

    private void updateTarget() {
        if (!inGame()) {
            this.target = null;
            return;
        }

        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            this.target = null;
            return;
        }

        double maxRange = range.getValue().doubleValue();
        double maxRangeSq = maxRange * maxRange;

        if (target == null || player.distanceToSqr(target) > maxRangeSq || !isValidTarget(target, player, maxRangeSq)) {
            target = findTarget(maxRange);
        }
    }

    private LivingEntity findTarget(double reach) {
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            return null;
        }

        AABB box = player.getBoundingBox().inflate(reach);
        double reachSq = reach * reach;
        double maxFov = fov.getValue().doubleValue();

        return mc.level.getEntitiesOfClass(LivingEntity.class, box, entity -> isValidTarget(entity, player, reachSq))
                .stream()
                .filter(entity -> {
                    if (player.distanceToSqr(entity) > reachSq) {
                        return false;
                    }
                    double entityFov = MathUtils.getFov(player, entity.getBoundingBox().getCenter());
                    return entityFov <= maxFov;
                })
                .min(Comparator.comparingDouble(this::sortTarget))
                .orElse(null);
    }

    private double sortTarget(LivingEntity entity) {
        return MathUtils.getFov(mc.player, entity.getBoundingBox().getCenter());
    }

    private boolean isValidTarget(LivingEntity entity, LocalPlayer player, double rangeSq) {
        if (entity == null || entity == player) {
            return false;
        }
        if (!entity.isAlive() || entity.isInvulnerable() || !entity.isAttackable()) {
            return false;
        }
        if (player.distanceToSqr(entity) > rangeSq) {
            return false;
        }
        if (entity instanceof ArmorStand) {
            return false;
        }

        if (checks.isSelected("Visible only") && !player.hasLineOfSight(entity)) {
            return false;
        }

        if (entity instanceof Player otherPlayer) {
            if (otherPlayer.isSpectator() || otherPlayer.isCreative()) {
                return false;
            }
            boolean isFriend = FriendManager.INSTANCE.isFriend(otherPlayer.getGameProfile().name());
            if (isFriend && !targets.isSelected("Friends")) {
                return false;
            }
            return targets.isSelected("Players");
        } else if (entity instanceof Animal || entity instanceof AmbientCreature) {
            return targets.isSelected("Animals");
        } else if (entity instanceof Monster || entity instanceof Phantom || entity instanceof Bat || entity instanceof Shulker || entity instanceof Villager) {
            return targets.isSelected("Mobs");
        }

        return false;
    }

    private boolean isHoldingWeapon(LocalPlayer player) {
        ItemStack held = player.getMainHandItem();
        return held.is(ItemTags.SWORDS) || held.is(ItemTags.AXES) || held.is(ItemTags.MACE_ENCHANTABLE);
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!isEnabled() || !inGame() || !sprintReset.getValue()) {
            return;
        }
        LocalPlayer player = mc.player;
        if (player == null || !player.isSprinting()) {
            return;
        }

        double maxReach = range.getValue().doubleValue();
        double reachSq = maxReach * maxReach;

        boolean canReset = false;
        if (this.target != null && player.distanceToSqr(this.target) <= reachSq) {
            if (!resetOnlyWhenAimed.getValue()) {
                canReset = true;
            } else {
                double fovToTarget = MathUtils.getFov(player, this.target.getBoundingBox().getCenter());
                if (fovToTarget <= 35.0D || mc.crosshairPickEntity == this.target) {
                    canReset = true;
                }
            }
        } else if (mc.crosshairPickEntity instanceof LivingEntity living && isValidTarget(living, player, reachSq)) {
            canReset = true;
        }

        if (canReset) {
            triggerSprintReset(player);
        }
    }

    private void triggerSprintReset(LocalPlayer player) {
        if (sprintResetMode.is("Packet")) {
            if (player.connection != null) {
                player.connection.send(new ServerboundPlayerCommandPacket(player, ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
                player.setSprinting(false);
            }
        } else if (sprintResetMode.is("S-Tap")) {
            SprintManager.onAttack(SprintManager.ResetMode.S_TAP);
        } else {
            SprintManager.onAttack(SprintManager.ResetMode.W_TAP);
        }
    }
}
